﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;
using System.Windows.Markup;
using System.IO.Packaging;

namespace WpfApplication1
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
                TextBlock txt;
                Image img;
                StackPanel panel;

                FixedPrintManager pm = new FixedPrintManager(borders: new Thickness(15), ShowPrintDialog: true);

                panel = new StackPanel();
                txt = pm.NewTextBlock("Times New Roman", 40);
                txt.Text = "Hier steht zum Beispiel jede Menge Text. Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.";
                panel.Children.Add(txt);
                txt = pm.NewTextBlock(text: "Hier steht zum Beispiel jede Menge Text. Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.");
                txt.TextAlignment = TextAlignment.Justify;
                txt.Margin = new Thickness(0, 10, 0, 20);
                panel.Children.Add(txt);
                img = new Image();
                img.Width = pm.PageSize.Width - pm.Borders.Left - pm.Borders.Right;
                img.Stretch = Stretch.Uniform;
                img.Source = new BitmapImage(new Uri("pack://application:,,,/Desert.jpg"));
                panel.Children.Add(img);
                pm.NewPage(panel);

                // Eine reine Text-Seite
                txt = pm.NewTextBlock(Fontsize: 22);
                txt.Text = "Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. Hier ist die zweite Seite mit Fließtext. ";
                pm.NewPage(txt);

                // Es geht auch ganz einfach
                pm.NewPage(new Calendar());

                // Bildausgabe bedreht    
                Canvas cv = new Canvas();
                img = new Image();
                img.Width = pm.PageSize.Width - pm.Borders.Left - pm.Borders.Right;
                img.Stretch = Stretch.Uniform;
                img.Source = new BitmapImage(new Uri("pack://application:,,,/Desert.jpg"));
                img.SetValue(Canvas.TopProperty, 100.0);
                img.SetValue(Canvas.LeftProperty, 1.0);
                img.LayoutTransform = new RotateTransform(45);
                cv.Children.Add(img);
                pm.NewPage(cv);

                // XAML-Daten aus Ressourcen laden
                cv = (Canvas)Resources["ResourceData"];
                cv.Measure(pm.PageSize);
                cv.Arrange(new Rect(0, 0, cv.DesiredSize.Width, cv.DesiredSize.Height));
                pm.NewPage(cv);    

                documentViewer1.Document = pm.Document;
                // Optional direkter Druck
                // pm.Print();
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            FlowPrintManager fpm = new FlowPrintManager(new Thickness(75, 25,25,25), true);
            fpm.FlowDoc.Blocks.Add(new Paragraph(new Run("Hier steht zum Beispiel jede Menge Text. Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.")));
            fpm.FlowDoc.Blocks.Add(new Paragraph(new LineBreak()));
                  for (int i=0; i<40; i++)
            fpm.FlowDoc.Blocks.Add(new Paragraph(new Run("Hier steht zum Beispiel jede Menge Text. Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.Hier steht zum Beispiel jede Menge Text.")));
            documentViewer1.Document = fpm.Document;
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {

        }
    }

    public class FixedPrintManager
    {
        private FixedDocument _PrintDocument;
        private Size _PageSize;
        private Thickness _Borders;
        private PrintDialog _dlg;

        public Thickness Borders
        {
            get { return _Borders; }
        }

        public Size PageSize
        {
            get { return _PageSize; }
            set { _PageSize = value; }
        }

        public FixedDocument Document
        {
            get { return _PrintDocument; }
        }

        public void Print(string title = "Mein Druckauftrag")
        {
            _dlg.PrintDocument(_PrintDocument.DocumentPaginator, title);
        }

        public TextBlock NewTextBlock(string Fontname = "Arial", int Fontsize = 12, string text = "")
        {
            TextBlock txt = new TextBlock();
            txt.Width = _PageSize.Width - _Borders.Left - _Borders.Right;
            txt.FontFamily = new FontFamily(Fontname);
            txt.FontSize = Fontsize;
            txt.Text = text;
            txt.TextWrapping = TextWrapping.WrapWithOverflow;
            return txt;
        }

        public FixedPrintManager(Thickness borders, bool ShowPrintDialog = false)
        {
            _PrintDocument = new FixedDocument();
            _dlg = new PrintDialog();
            if (ShowPrintDialog) _dlg.ShowDialog();
            _PageSize = new Size(_dlg.PrintableAreaWidth, _dlg.PrintableAreaHeight);
            _PrintDocument.DocumentPaginator.PageSize = _PageSize;
            _Borders = borders;
        }

        public void NewPage(UIElement content)
        {
            FixedPage _page = new FixedPage();
            _page.Width = _PrintDocument.DocumentPaginator.PageSize.Width;
            _page.Height = _PrintDocument.DocumentPaginator.PageSize.Height;
            _page.Margin = _Borders;
            _page.Children.Add(content);
            PageContent _pageContent = new PageContent();
            ((IAddChild)_pageContent).AddChild(_page);
            _PrintDocument.Pages.Add(_pageContent);
        }
    }

    public class FlowPrintManager
    {
        private FlowDocument _flowdocument;
        private FixedDocumentSequence _document;
        private MemoryStream ms;
        private Package package;
        private PrintDialog _dlg;

        public FlowDocument FlowDoc
        {
            get 
            {return _flowdocument; }
        }

        public FixedDocumentSequence Document
        {
            get 
            {
                // Pauschal erstmal löschen    
                PackageStore.RemovePackage(new Uri("memorystream://data.xps"));
                PackageStore.AddPackage(new Uri("memorystream://data.xps"), package);
                XpsDocument xpsDocument = new XpsDocument(package, CompressionOption.Fast, "memorystream://data.xps");
                XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                writer.Write(((IDocumentPaginatorSource)_flowdocument).DocumentPaginator);
                _document = xpsDocument.GetFixedDocumentSequence();
                xpsDocument.Close();
                return _document; 
            }
        }

        public FlowPrintManager(Thickness borders, bool ShowPrintDialog = false)
        {
            ms = new MemoryStream();
            package = Package.Open(ms, FileMode.Create, FileAccess.ReadWrite);
            _dlg = new PrintDialog();
            if (ShowPrintDialog) _dlg.ShowDialog();
            _flowdocument = new FlowDocument();
            _flowdocument.ColumnWidth = _dlg.PrintableAreaWidth;
            _flowdocument.PageHeight = _dlg.PrintableAreaHeight;
            _flowdocument.PagePadding = borders;
        }

        public void Print(string title = "Mein Druckauftrag")
        {
            _dlg.PrintDocument(this.Document.DocumentPaginator, title);
        }

    }

}
