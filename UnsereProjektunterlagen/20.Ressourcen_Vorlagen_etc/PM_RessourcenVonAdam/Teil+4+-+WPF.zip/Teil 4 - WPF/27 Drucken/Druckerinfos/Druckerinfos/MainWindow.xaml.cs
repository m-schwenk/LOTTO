﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

// Achtung: System.Printing.dll einbinden
// Achtung: ReachFramework.dll ein
using System.Printing;
using System.Collections;

namespace Druckerinfos
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // lokalen Printserver abrufen
            var server = new LocalPrintServer();
            // alle Drucker bestimmen
            var queues = server.GetPrintQueues();
            // an Listbox1 binden
            ListBox1.ItemsSource = queues;
            ListBox1.DisplayMemberPath = "Name";
        }

        private void ListBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var capabilities = ((PrintQueue)ListBox1.SelectedItem).GetPrintCapabilities();
            ListBox2.ItemsSource = capabilities.PageMediaSizeCapability;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            // Drucker auswählen
            var queue = (PrintQueue) ListBox1.SelectedItem;
            queue.UserPrintTicket.PageOrientation = PageOrientation.Landscape;

            // Eine reine Text-Seite
            TextBlock txt = new TextBlock();
            txt.Text = "Hier ist eine Seite mit Fließtext. Hier ist eine Seite mit Fließtext. Hier ist eine Seite mit Fließtext. Hier ist eine Seite mit Fließtext. Hier ist eine Seite mit Fließtext. ";

            txt.Measure(new Size((double) queue.UserPrintTicket.PageMediaSize.Height, 200)); // Achtung : Wir haben die Seite gedreht
            txt.Arrange(new Rect(0, 0, txt.DesiredSize.Width, txt.DesiredSize.Height));

            var writer = PrintQueue.CreateXpsDocumentWriter(queue);
            writer.Write(txt);
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog dlg = new PrintDialog();
            if (dlg.ShowDialog() == true)
            {
                TextBlock txt = new TextBlock();
                txt.Margin = new Thickness(15);
                txt.Text = "Hier folgt ein selten belangloser Text, den Sie besser nicht lesen sollten. Aber so wird Ihnen schnell klar, wie einfach die Textausgabe ist.";
                txt.FontSize = 25;
                txt.TextWrapping = TextWrapping.Wrap;
                txt.FontFamily = new FontFamily("Arial");
                txt.Measure(new Size(dlg.PrintableAreaWidth, dlg.PrintableAreaHeight));
                txt.Arrange(new Rect(0, 0, txt.DesiredSize.Width, txt.DesiredSize.Height));
                dlg.PrintVisual(txt, "Erster Test"); 
            }
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
