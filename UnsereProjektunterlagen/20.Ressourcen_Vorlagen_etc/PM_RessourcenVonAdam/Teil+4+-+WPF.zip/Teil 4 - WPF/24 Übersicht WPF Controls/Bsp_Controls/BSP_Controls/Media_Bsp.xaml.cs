﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Media_Bsp.xaml
    /// </summary>
    public partial class Media_Bsp : Window
    {
        System.Windows.Forms.Timer time = new System.Windows.Forms.Timer();

        public Media_Bsp()
        {
            InitializeComponent();
            time.Interval = 100;
            time.Tick += new EventHandler(time_Tick);
        }

        void time_Tick(object sender, EventArgs e)
        {
            Title = DateTime.Now.ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Media1.Play();
            time.Start();
            //Media1.Volume = (double)VSlider.Value;
            //Media1.SpeedRatio = (double)SSlider.Value;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Media1.Pause();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Media1.Stop();
            time.Stop();
        }

        private void VSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Media1 != null) Media1.Volume = (double)VSlider.Value;
        }

        private void SSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
           if (Media1!=null) Media1.SpeedRatio = (double)SSlider.Value;
        }

        private void Media1_MediaOpened(object sender, RoutedEventArgs e)
        {
            // nach dem Öffnen
        }

        private void Media1_MediaEnded(object sender, RoutedEventArgs e)
        {
            time.Stop();
        }
    }
}
