﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Image_Bsp.xaml
    /// </summary>
    public partial class Image_Bsp : Window
    {
        public Image_Bsp()
        {
            InitializeComponent();
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            BitmapImage bi = new BitmapImage();
            bi.BeginInit();
//            bi.UriSource = new Uri("pack://application:,,,/images/frosch.gif");
            bi.DecodePixelWidth = 50;
            bi.UriSource = new Uri("images/frosch.gif",UriKind.Relative);
            bi.EndInit();

            Image5.Source = bi;
            //Image5.Source = BitmapFrame.Create(new Uri("pack://application:,,,/images/frosch.gif"));

            OpenFileDialog Dlg = new OpenFileDialog();
            Dlg.Title = "Dateiauswahl";
            Dlg.DefaultExt = "jpg";
            if ((bool)Dlg.ShowDialog())
            {
                string file = Dlg.FileName;
                Image6.Source = BitmapFrame.Create(new Uri(file));
            }
        }
    }
}
