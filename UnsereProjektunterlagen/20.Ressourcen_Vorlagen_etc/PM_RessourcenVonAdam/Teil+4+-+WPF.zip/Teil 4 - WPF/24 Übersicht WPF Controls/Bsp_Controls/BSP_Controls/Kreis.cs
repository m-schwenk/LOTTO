﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows;

namespace BSP_Controls
{
    class Kreis : DependencyObject
    {
        public static readonly DependencyProperty DurchmesserProperty =
             DependencyProperty.Register("Durchmesser", typeof(double), typeof(Kreis),
                                          new FrameworkPropertyMetadata(11.1,
                                          new PropertyChangedCallback(OnDurchmesserChanged)));
        
        public double Durchmesser
        {
            get { return (double)(GetValue(DurchmesserProperty)); }
            set { SetValue(DurchmesserProperty, value); }
        }

        private static void OnDurchmesserChanged(DependencyObject obj,
            DependencyPropertyChangedEventArgs args)
        {
            MessageBox.Show( (obj as Kreis).Durchmesser.ToString());
        }
    }

    class XKreis
    {
        private double d;

        public double Durchmesser
        {
            get { return d; }
            set { d = value; }
        }
    }

}
