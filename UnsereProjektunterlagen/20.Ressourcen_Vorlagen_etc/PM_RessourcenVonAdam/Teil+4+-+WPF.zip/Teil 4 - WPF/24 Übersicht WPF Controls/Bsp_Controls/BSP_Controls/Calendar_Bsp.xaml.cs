﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaktionslogik für Calendar_Bsp.xaml
    /// </summary>
    public partial class Calendar_Bsp : Window
    {
        public Calendar_Bsp()
        {
            InitializeComponent();
        }

        private void DatePicker1_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            Label1.Content = DatePicker1.SelectedDate.ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var datum in Calendar1.SelectedDates)
            {
                MessageBox.Show(datum.ToString());  
            }
        }
    }
}
