﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Slider_Scrollbar.xaml
    /// </summary>
    public partial class Slider_Scrollbar : Window
    {
        public Slider_Scrollbar()
        {
            InitializeComponent();
        }

        private void ScrollBar_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {
            Title = scrollBar1.Value.ToString();
        }

        private void ScrollBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
        //    Title = scrollBar1.Value.ToString();
        }
    }
}
