﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaktionslogik für FlowDocumentperCode.xaml
    /// </summary>
    public partial class FlowDocumentperCode : Window
    {
        public FlowDocumentperCode()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FlowDocument flowDoc = new FlowDocument();

            Paragraph para = new Paragraph(new Bold(new Run("Wir schreiben etwas Text in den ersten Absatz.")));
            para.Inlines.Add(new Run(" Hier kommt noch mehr Text im selben Absatz"));
            flowDoc.Blocks.Add(para);
            List liste = new List();
            liste.ListItems.Add(new ListItem(new Paragraph(new Run("Zeile 1"))));
            liste.ListItems.Add(new ListItem(new Paragraph(new Run("Zeile 2"))));
            liste.ListItems.Add(new ListItem(new Paragraph(new Run("Zeile 3"))));
            flowDoc.Blocks.Add(liste);

            FlowDocumentPageViewer1.Document = flowDoc;
        }
    }
}
