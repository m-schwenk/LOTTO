﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for TextBox_PasswordBox.xaml
    /// </summary>
    public partial class TextBox_PasswordBox : Window
    {
        public TextBox_PasswordBox()
        {
            InitializeComponent();
        }

        private void PasswordBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                MessageBox.Show(Pwd1.Password);
        }

    }
}
