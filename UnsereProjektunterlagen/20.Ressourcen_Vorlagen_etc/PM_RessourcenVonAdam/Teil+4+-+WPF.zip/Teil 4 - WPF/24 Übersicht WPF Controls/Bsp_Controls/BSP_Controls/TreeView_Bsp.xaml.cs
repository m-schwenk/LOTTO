﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for TreeView_Bsp.xaml
    /// </summary>
    public partial class TreeView_Bsp : Window
    {
        public TreeView_Bsp()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            TreeViewItem tvi;
            Tv1.Items.Clear();
            tvi = new TreeViewItem { Header = "Root" };
            tvi.Items.Add(new TreeViewItem { Header = "Untereintrag 1" });
            tvi.Items.Add(new TreeViewItem { Header = "Untereintrag 2" });
            tvi.Items.Add(new TreeViewItem { Header = "Untereintrag 3" });
            tvi.Items.Add(new TreeViewItem { Header = "Untereintrag 4" });
            Tv1.Items.Add(tvi);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
