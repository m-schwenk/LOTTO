﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Test.xaml
    /// </summary>
    public partial class Test : Window
    {

        Kreis myKreis = new Kreis();

        public Test()
        {
            InitializeComponent();
            StackPanel1.DataContext = myKreis;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
          MessageBox.Show(myKreis.Durchmesser.ToString());
        }
    }
}
