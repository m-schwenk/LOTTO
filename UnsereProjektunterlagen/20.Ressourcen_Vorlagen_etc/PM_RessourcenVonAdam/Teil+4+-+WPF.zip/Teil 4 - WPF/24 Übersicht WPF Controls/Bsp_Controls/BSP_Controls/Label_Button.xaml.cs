﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void RepeatButton_Click(object sender, RoutedEventArgs e)
        {
            Title = Title + ".";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Klick!!!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ModalWindow w2 = new ModalWindow();
            w2.ShowDialog();
            if ((bool)w2.DialogResult)
                MessageBox.Show("OK");
            else
                MessageBox.Show("Abbruch");
        }
    }
}
