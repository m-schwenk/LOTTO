﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for ListBox_ComboBox.xaml
    /// </summary>
    public partial class ListBox_ComboBox : Window
    {
        public ListBox_ComboBox()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (ListBox1.SelectedIndex != -1)
            {
                MessageBox.Show("Es ist mindestens ein Eintrag markiert!");
                MessageBox.Show("Zeile " + ListBox1.SelectedIndex.ToString() + " ist markiert!");
                foreach (ListBoxItem item in ListBox1.SelectedItems)
                {
                    MessageBox.Show(item.Content.ToString());
                }
            }
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ListBox2.Items.Clear();
            CheckBox cb = new CheckBox();
            cb.Content = "Ein Test";
            ListBox2.Items.Add(cb);

            ListBox2.Items.Add(new CheckBox{Content="asdasdasda"});

            for (int i = 1; i < 50; i++)
                ListBox2.Items.Add("Zeile" + i.ToString());                
        }

        private void ComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MessageBox.Show("Markierte Zeile: " + ComboBox1.SelectedIndex.ToString());
            // Achtung, hier ist Text noch nicht gesetzt!!!!
        }
    }
}
