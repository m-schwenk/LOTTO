﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace BSP_Controls
{
    /// <summary>
    /// Interaktionslogik für Browser_Bsp.xaml
    /// </summary>
    public partial class Browser_Bsp : Window
    {
        public Browser_Bsp()
        {
            InitializeComponent();
        }

        private void txt1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
               webBrowser1.Source = new Uri(txt1.Text);  
            }
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
           webBrowser1.NavigateToString("<HTML><BODY>Ein einfaches <b>HTML-Dokument</b><br> mit wenig <u>Text</u>.</BODY></HTML>");
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri(@"pack://application:,,,/info.htm", UriKind.Absolute);
            Stream src = Application.GetResourceStream(uri).Stream;
            webBrowser1.NavigateToStream(src);
        }
    }
}
