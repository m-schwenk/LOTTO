﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for Border_GroupBox_BulletDecorator.xaml
    /// </summary>
    public partial class Border_GroupBox_BulletDecorator : Window
    {
        public Border_GroupBox_BulletDecorator()
        {
            InitializeComponent();
        }
    }
}
