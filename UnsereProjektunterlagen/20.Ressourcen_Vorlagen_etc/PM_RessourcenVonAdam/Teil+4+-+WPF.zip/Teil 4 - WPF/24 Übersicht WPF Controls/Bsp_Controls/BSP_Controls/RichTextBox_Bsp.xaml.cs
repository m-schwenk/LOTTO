﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;

namespace BSP_Controls
{
    /// <summary>
    /// Interaction logic for RichTextBox_Bsp.xaml
    /// </summary>
    public partial class RichTextBox_Bsp : Window
    {
        public RichTextBox_Bsp()
        {
            InitializeComponent();
        }

        private void newb_Click(object sender, RoutedEventArgs e)
        {
            rtb1.Document = new FlowDocument();
        }

        private void Saveb_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Xaml(*.xaml)|*.xaml";
            if ((bool)dialog.ShowDialog())
            {
                FileStream fs = (FileStream)dialog.OpenFile();
                TextRange tr = new TextRange(rtb1.Document.ContentStart,
                                             rtb1.Document.ContentEnd);
                tr.Save(fs, DataFormats.XamlPackage);
                rtb1.Selection.Save(fs, DataFormats.XamlPackage);
                fs.Close();
            }
        }

        private void openb_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Xaml(*.xaml)|*.xaml";
            if((bool)dialog.ShowDialog())
            {
                FileStream fs = (FileStream)dialog.OpenFile();
                TextRange tr = new TextRange(rtb1.Document.ContentStart,
                                             rtb1.Document.ContentEnd);
                //tr.Load(fs, DataFormats.XamlPackage);
                rtb1.Selection.Load(fs, DataFormats.XamlPackage);
                fs.Close();
            }
        }

        private void printb_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog dialog = new PrintDialog();
            if ((bool)dialog.ShowDialog())
            {
                dialog.PrintVisual(rtb1 as Visual, "printing as visual");
                dialog.PrintDocument((((IDocumentPaginatorSource)rtb1.Document).DocumentPaginator), "printing as paginator");
            }
        }

        private void boldb_Click(object sender, RoutedEventArgs e)
        {
          //  rtb1.Selection.ApplyPropertyValue(FlowDocument.FontWeightProperty,
          //                                    FontWeights.Bold);
       
        }

        private void italicb_Click(object sender, RoutedEventArgs e)
        {
            rtb1.Selection.ApplyPropertyValue(FlowDocument.FontStyleProperty,
                                               FontStyles.Italic);
        }


        private void rtb1_SelectionChanged(object sender, RoutedEventArgs e)
        {
            object propval = rtb1.Selection.GetPropertyValue(FontWeightProperty);
            if (propval != DependencyProperty.UnsetValue)
                boldb.IsChecked = (FontWeight)propval == FontWeights.Bold;
           
            propval = rtb1.Selection.GetPropertyValue(FontStyleProperty);
            if (propval != DependencyProperty.UnsetValue)
               italicb.IsChecked = (FontStyle)propval == FontStyles.Italic;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            rtb1.Document.Blocks.InsertBefore(rtb1.Selection.Start.Paragraph, new Paragraph(new Run("sdasd")));

        }

        void img_MouseDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Finger weg!");
        }

        private void imageb_Click(object sender, RoutedEventArgs e)
        {
            Image img = new Image();
            img.Source = BitmapFrame.Create(new Uri("pack://application:,,,/images/frosch.gif")); // grid.Background = new SolidColorBrush(Colors.Red);
            img.Height = 100;
            img.Width = 100;
            img.MouseDown += delegate { MessageBox.Show("Finger weg!"); }; //new MouseButtonEventHandler(img_MouseDown); 
            rtb1.Document.Blocks.Add(new Paragraph( new InlineUIContainer(img)));
            rtb1.Document.Blocks.Add(new Paragraph(new InlineUIContainer(new Button())));
        }


    }
}
