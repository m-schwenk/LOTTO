﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Controls.Ribbon;

namespace Ribbon_Bsp
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : RibbonWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 0; i < 10; i++)
                RibbonGalleryCategory1.Items.Add("Zeile " + i.ToString());
            for (int i = 0; i < 6; i++)
                RibbonGalleryCategory2.Items.Add("Zeile " + i.ToString());

            DateiListe1.Items.Add("Kündigung Müller.doc");
            DateiListe1.Items.Add("Kündigung Maier.doc");
            DateiListe1.Items.Add("Kündigung Lorenz.doc");
            DateiListe1.Items.Add("Kündigung Schmidt.doc");
            DateiListe1.Items.Add("Kündigung Heinze.doc");
            DateiListe1.Items.Add("Kündigung Koch.doc");
            DateiListe1.Items.Add("Kündigung Walter.doc");
            DateiListe1.Items.Add("Kündigung Gewinnus.doc");
        }

        private void RibbonGallery_SelectionChanged_1(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            MessageBox.Show(e.NewValue.ToString());
        }

    }
}
