﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO;
using System.Windows.Ink;                   
using System.Windows.Markup;                


namespace Bsp_InkCanvas
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            comboBox1.Items.Add(new { desc = "Ink", value = InkCanvasEditingMode.Ink });
            comboBox1.Items.Add(new { desc = "Erase by Point", value = InkCanvasEditingMode.EraseByPoint });
            comboBox1.Items.Add(new { desc = "Erase by Stroke", value = InkCanvasEditingMode.EraseByStroke});
            comboBox1.Items.Add(new { desc = "Select", value = InkCanvasEditingMode.Select });
            comboBox1.DisplayMemberPath = "desc";
            comboBox1.SelectedValuePath = "value";
            comboBox1.SelectedIndex = 0;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (FileStream fs = new FileStream(@"c:\test.bmp",FileMode.Create, FileAccess.Write))
            {
                RenderTargetBitmap rtb = new RenderTargetBitmap((int)InkCanvas1.ActualWidth,
                                    (int)InkCanvas1.ActualHeight, 0, 0, PixelFormats.Default);
                rtb.Render(InkCanvas1);
                BmpBitmapEncoder encoder = new BmpBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(rtb));
                encoder.Save(fs);
                fs.Close();
            }
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            InkCanvas1.EditingMode = (InkCanvasEditingMode)comboBox1.SelectedValue;
        }

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            InkCanvas1.DefaultDrawingAttributes.Width = slider1.Value;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (FileStream fs = new FileStream(@"c:\test.ink", FileMode.Create, FileAccess.Write))
            {
                InkCanvas1.Strokes.Save(fs);
                fs.Close();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            InkCanvas1.Strokes.Clear();
            using (FileStream fs = new FileStream(@"c:\test.ink", FileMode.Open, FileAccess.Read))
            {
                InkCanvas1.Strokes = new StrokeCollection(fs);
                fs.Close();
            }
        }

        private void checkBox1_Checked(object sender, RoutedEventArgs e)
        {
            InkCanvas1.DefaultDrawingAttributes.FitToCurve = (bool)checkBox1.IsChecked;
        }

        private void checkBox2_Checked(object sender, RoutedEventArgs e)
        {
            InkCanvas1.DefaultDrawingAttributes.IgnorePressure = (bool)checkBox2.IsChecked;

        }

        private void checkBox3_Checked(object sender, RoutedEventArgs e)
        {
            InkCanvas1.DefaultDrawingAttributes.IsHighlighter = (bool)checkBox3.IsChecked;
        }

        private void checkBox1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
