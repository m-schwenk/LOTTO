﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Collections.Specialized;

namespace DataGrid_Bsp
{
    public class Schüler : INotifyPropertyChanged
    {
        string _Nachname;
        string _Vorname;
        DateTime _Geburtstag;

        public event PropertyChangedEventHandler PropertyChanged;

        public DateTime Geburtstag
        {
            get { return _Geburtstag; }
            set 
            {
                _Geburtstag = value;
                NotifyPropertyChanged("Geburtstag");
            }
        }

        public string Vorname
        {
            get { return _Vorname; }
            set 
            { 
                _Vorname = value;
                NotifyPropertyChanged("Vorname");
            }
        }

        public string Nachname
        {
            get { return _Nachname; }
            set 
            { 
                _Nachname = value;
                NotifyPropertyChanged("Nachname");
            }
        }

        public override string ToString()
        {
            return this._Nachname + ", " + this._Vorname;
        }

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(info));
        }

    }
}
