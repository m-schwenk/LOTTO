﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für EinfacheListe.xaml
    /// </summary>
    public partial class EinfacheListe : Window
    {

        public ObservableCollection<Schüler> Klasse;

        public EinfacheListe()
        {
            InitializeComponent();
            Klasse = new ObservableCollection<Schüler>();
            Klasse.Add(new Schüler
            {
                Nachname = "Mayer",
                Vorname = "Alexander",
                Geburtstag = new DateTime(2001, 11, 7)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Müller",
                Vorname = "Thomas",
                Geburtstag = new DateTime(2001, 10, 18)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Lehmann",
                Vorname = "Walter",
                Geburtstag = new DateTime(2001, 1, 21)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Richter",
                Vorname = "Johannes",
                Geburtstag = new DateTime(2001, 1, 21)
            }); 
            this.DataContext = Klasse;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            listBox1.SelectedIndex = 1;
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(listBox1.SelectedItem.ToString());
            MessageBox.Show((listBox1.SelectedItem as Schüler).Nachname);
            foreach (Schüler s in listBox1.SelectedItems)
                MessageBox.Show(s.Nachname);
            MessageBox.Show(listBox1.SelectedValue.ToString());
        }

        protected bool MeinFilter(object value)
        {
            Schüler s = value as Schüler;
            return s.Vorname.StartsWith("T");
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(listBox1.ItemsSource);
            view.Filter += MeinFilter;
        }

        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            Klasse.Add(new Schüler
            {
                Nachname = "Müller",
                Vorname = "Gerhard",
                Geburtstag = new DateTime(2001, 10, 18)
            });
        }

        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            Schüler schueler = Klasse.Where(sch => sch.Vorname == "Thomas").FirstOrDefault();
            schueler.Vorname = "aaaa";

            //ICollectionView view = CollectionViewSource.GetDefaultView(listBox1.ItemsSource);
            //view.Refresh();
        }

        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(listBox1.ItemsSource);
            view.Filter += MeinFilter;
            ICollectionViewLiveShaping viewls = view as ICollectionViewLiveShaping;

            if (viewls == null)
            {
                MessageBox.Show("Nicht unterstützt!");
            }
            if (viewls.CanChangeLiveFiltering)
            {
                viewls.LiveFilteringProperties.Add("Vorname");
                viewls.IsLiveFiltering = true;
            }
        }

    }
}
