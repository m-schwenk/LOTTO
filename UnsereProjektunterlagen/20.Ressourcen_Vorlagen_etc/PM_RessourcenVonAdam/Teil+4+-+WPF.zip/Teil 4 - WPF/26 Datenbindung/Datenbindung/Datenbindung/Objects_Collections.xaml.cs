﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Datenbindung
{
    /// <summary>
    /// Interaction logic for Objects_Collections.xaml
    /// </summary>
    public partial class Objects_Collections : Window
    {
        public ObservableCollection<Schüler> Klasse;
        private ICollectionView view;

        public Objects_Collections()
        {
            Klasse = new ObservableCollection<Schüler>();
            Klasse.Add(new Schüler { Nachname = "Mayer", Vorname = "Alexander", Geburtstag = new DateTime(2001, 11, 7) });
            Klasse.Add(new Schüler { Nachname = "Müller", Vorname = "Thomas", Geburtstag = new DateTime(2001, 10, 18) });
            Klasse.Add(new Schüler { Nachname = "Lehmann", Vorname = "Walter", Geburtstag = new DateTime(2001, 1, 21) });
            InitializeComponent();
            this.DataContext = Klasse;
            this.view = CollectionViewSource.GetDefaultView(Klasse);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            view.MoveCurrentToNext();
            if (view.IsCurrentAfterLast) view.MoveCurrentToLast();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            view.MoveCurrentToPrevious();
            if (view.IsCurrentBeforeFirst) view.MoveCurrentToFirst();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Klasse.Add(new Schüler { Nachname = "Möhre", Vorname = "Willi", Geburtstag = new DateTime(1919, 1, 1) });
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Klasse.Remove(view.CurrentItem as Schüler);
        }
    }
}
