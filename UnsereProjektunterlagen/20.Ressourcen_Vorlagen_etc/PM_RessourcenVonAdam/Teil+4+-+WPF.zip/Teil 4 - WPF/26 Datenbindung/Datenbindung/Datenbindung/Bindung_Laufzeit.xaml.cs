﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für Bindung_Laufzeit.xaml
    /// </summary>
    public partial class Bindung_Laufzeit : Window
    {

        public Bindung_Laufzeit()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Binding binding = new Binding("Content");
            binding.Source = Button1;
            binding.Mode = BindingMode.OneWay;
            Label1.SetBinding(Label.ContentProperty, binding);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button1.Content = "Ein neuer Text";
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
         //   Label1.Content = "Bindung beendet";
           Label1.ClearValue(Label.ContentProperty);
        }
    }
}
