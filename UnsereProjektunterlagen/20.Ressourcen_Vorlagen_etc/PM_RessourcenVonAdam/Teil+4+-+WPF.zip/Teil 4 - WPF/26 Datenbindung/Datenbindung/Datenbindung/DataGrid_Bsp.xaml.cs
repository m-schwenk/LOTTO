﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für DataGrid_Bsp.xaml
    /// </summary>
    public partial class DataGrid_Bsp : Window
    {
        NWDataContext db;
        public ObservableCollection<Schüler> Klasse;

        public DataGrid_Bsp()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            DataGrid1.ItemsSource = Klasse;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Data.CollectionViewSource schülerViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("schülerViewSource")));
            Klasse = new ObservableCollection<Schüler>();
            for (int i = 0; i < 1000; i++)
                Klasse.Add(new Schüler { Nachname = "Mayer" + i.ToString(), Vorname = "Anton", Geburtstag = System.DateTime.Now });
            schülerViewSource.Source = Klasse;
        }
    }
}
