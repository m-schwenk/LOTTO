﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.ComponentModel;


namespace Datenbindung
{
    /// <summary>
    /// Interaction logic for DB_Bsp.xaml
    /// </summary>
    public partial class DB_Bsp : Window
    {
        NWDataContext db = new NWDataContext();
        ICollectionView viewO;

        public DB_Bsp()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lvOrder.DataContext = db.Orders;
            viewO = CollectionViewSource.GetDefaultView(lvOrder.DataContext);
        }

        private void lvOrder_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lvOrderDetails.DataContext = (viewO.CurrentItem as Order).Order_Details;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
