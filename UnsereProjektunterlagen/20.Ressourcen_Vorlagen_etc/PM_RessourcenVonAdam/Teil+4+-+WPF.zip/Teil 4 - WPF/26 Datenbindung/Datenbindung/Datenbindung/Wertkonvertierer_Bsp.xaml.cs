﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Datenbindung
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    /// 

    public partial class Window1 : Window
    {

        public Schüler Schueler;

        public Window1()
        {
            InitializeComponent();
            Schueler = new Schüler { Nachname = "Mayer", Vorname = "Alexander", Geburtstag = new DateTime(2001, 11, 7) };
            StackPanel1.DataContext = Schueler;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(Schueler.Nachname + ", " + Schueler.Vorname);
        }
    }
}
