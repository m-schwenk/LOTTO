﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für DragDrop_Bsp.xaml
    /// </summary>
    public partial class DragDrop_Bsp : Window
    {
        public DragDrop_Bsp()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Datenbindung.DB.NORTHWINDDataSet nORTHWINDDataSet = ((Datenbindung.DB.NORTHWINDDataSet)(this.FindResource("nORTHWINDDataSet")));
            // Load data into the table Products. You can modify this code as needed.
            Datenbindung.DB.NORTHWINDDataSetTableAdapters.ProductsTableAdapter nORTHWINDDataSetProductsTableAdapter = new Datenbindung.DB.NORTHWINDDataSetTableAdapters.ProductsTableAdapter();
            nORTHWINDDataSetProductsTableAdapter.Fill(nORTHWINDDataSet.Products);
            System.Windows.Data.CollectionViewSource productsViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("productsViewSource")));
            productsViewSource.View.MoveCurrentToFirst();
        }
    }
}
