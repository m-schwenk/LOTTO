﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für Laden_im_Hintergrund.xaml
    /// </summary>
    public partial class Laden_im_Hintergrund : Window
    {
        public ObservableCollection<Schüler> _klasse;

        public Laden_im_Hintergrund()
        {
            InitializeComponent();
            _klasse = new ObservableCollection<Schüler>();
            this.DataContext = _klasse;
        }


        private ObservableCollection<Schüler> Datenabrufen_alteLoesung()
        {
            ObservableCollection<Schüler> _threadklasse = new ObservableCollection<Schüler>();
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);  // simuliert Laden aus der Quelle
                _threadklasse.Add(new Schüler { Nachname = "Mayer" + i.ToString(), Vorname = "Alexander", Geburtstag = new DateTime(2001, 11, 7) });
            }
            return _threadklasse;
        }

      
        private void Datenabrufen()
        {
            _klasse.Clear();
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);  // simuliert Laden aus der Quelle
                _klasse.Add(new Schüler { Nachname = "Mayer" + i.ToString(), Vorname = "Alexander", Geburtstag = new DateTime(2001, 11, 7) });
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Datenabrufen();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Task.Factory.StartNew(Datenabrufen);
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            BindingOperations.EnableCollectionSynchronization(_klasse, this);
            Task.Factory.StartNew(Datenabrufen);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            this.Cursor = Cursors.Wait;
            Task.Factory.StartNew < ObservableCollection<Schüler>>(Datenabrufen_alteLoesung).ContinueWith(t =>
            {
                _klasse.Clear();
                foreach (var s in t.Result) 
                    _klasse.Add(s);
                this.Cursor = null;
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }


    }
}
