﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Datenbindung
{
    /// <summary>
    /// Interaktionslogik für ListView_Bsp.xaml
    /// </summary>
    public partial class ListView_Bsp : Window
    {
        public ObservableCollection<Schüler> Klasse;

        public ListView_Bsp()
        {
            InitializeComponent();
            Klasse = new ObservableCollection<Schüler>();
            Klasse.Add(new Schüler
            {
                Nachname = "Mayer",
                Vorname = "Alexander",
                Geburtstag = new DateTime(2001, 11, 7)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Müller",
                Vorname = "Thomas",
                Geburtstag = new DateTime(2001, 10, 18)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Lehmann",
                Vorname = "Walter",
                Geburtstag = new DateTime(2001, 1, 21)
            });
            Klasse.Add(new Schüler
            {
                Nachname = "Richter",
                Vorname = "Johannes",
                Geburtstag = new DateTime(2001, 1, 21)
            });
            this.DataContext = Klasse;

        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SortClick(object sender, RoutedEventArgs e)
        {
            GridViewColumnHeader spalte = sender as GridViewColumnHeader;
            ICollectionView view =   CollectionViewSource.GetDefaultView(ListView1.ItemsSource);
            view.SortDescriptions.Clear();
            view.SortDescriptions.Add(new SortDescription(spalte.Content.ToString(), ListSortDirection.Ascending));
            view.Refresh();
        }
    }
}
