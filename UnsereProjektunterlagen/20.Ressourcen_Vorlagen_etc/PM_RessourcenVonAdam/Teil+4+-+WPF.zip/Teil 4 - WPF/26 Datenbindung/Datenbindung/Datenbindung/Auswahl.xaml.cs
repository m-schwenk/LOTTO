﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Reflection;

namespace Datenbindung
{
    /// <summary>
    /// Interaction logic for Auswahl.xaml
    /// </summary>
    public partial class Auswahl : Window
    {
        private Assembly myass;

        public Auswahl()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            myass = Assembly.GetExecutingAssembly();
            foreach (Type t in myass.GetTypes())
                if ((t.BaseType.Name == "Window") & (t.Name != "Auswahl")) listBox1.Items.Add(t.Name);
        }

        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Window mywin = myass.CreateInstance(myass.GetName().Name + "." + listBox1.SelectedItem.ToString()) as Window;
            if (mywin == null) return;
            mywin.ShowDialog();
        }
    }
}
