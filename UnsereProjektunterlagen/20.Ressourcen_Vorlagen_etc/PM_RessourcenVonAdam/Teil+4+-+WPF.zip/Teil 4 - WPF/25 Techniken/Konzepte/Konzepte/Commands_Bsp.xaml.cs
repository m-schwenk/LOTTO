﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Konzepte
{
    /// <summary>
    /// Interaktionslogik für Commands_Bsp.xaml
    /// </summary>
    public partial class Commands_Bsp : Window
    {
        public Commands_Bsp()
        {
            InitializeComponent();
            CommandBinding cmdOpen = new CommandBinding(ApplicationCommands.Open);
            cmdOpen.Executed += new ExecutedRoutedEventHandler(cmdOpen_Executed);
        }

        void cmdOpen_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ApplicationCommands.Paste.Execute(null, txt2);
        }

        void OpenCmdExecuted(object target, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("Was soll ich öffnen????");
        }

        void OpenCmdCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if (txt1.Text.Length == 0)
               e.CanExecute = true;
            else
               e.CanExecute = false;

        }

    }
}
