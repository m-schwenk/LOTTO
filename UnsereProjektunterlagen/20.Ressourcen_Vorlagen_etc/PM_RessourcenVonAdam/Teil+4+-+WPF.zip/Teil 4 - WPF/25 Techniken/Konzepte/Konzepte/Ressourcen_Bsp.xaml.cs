﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Konzepte
{
    /// <summary>
    /// Interaction logic for Ressourcen_Bsp.xaml
    /// </summary>
    public partial class Ressourcen_Bsp : Window
    {
        public Ressourcen_Bsp()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ImageBrush imgbck = new ImageBrush();
            imgbck.ImageSource = new BitmapImage(new Uri("pack://application:,,,/back2.jpg"));
            this.Resources.Add("bck1", imgbck);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ImageBrush imgbck = new ImageBrush();
            imgbck.ImageSource = new BitmapImage(new Uri("pack://application:,,,/back2.jpg"));
            this.Resources["bck"] = imgbck;

        }
    }
}
