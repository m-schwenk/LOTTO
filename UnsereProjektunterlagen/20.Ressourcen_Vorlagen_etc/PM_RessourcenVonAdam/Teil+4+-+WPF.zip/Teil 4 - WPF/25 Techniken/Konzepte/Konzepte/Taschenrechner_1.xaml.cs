﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Reflection;

namespace Konzepte
{
    /// <summary>
    /// Interaktionslogik für Taschenrechner_1.xaml
    /// </summary>
    public partial class Taschenrechner_1 : Window
    {
        public Taschenrechner_1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           button10.Style = (Style)FindResource("myBtnStyle2");
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
