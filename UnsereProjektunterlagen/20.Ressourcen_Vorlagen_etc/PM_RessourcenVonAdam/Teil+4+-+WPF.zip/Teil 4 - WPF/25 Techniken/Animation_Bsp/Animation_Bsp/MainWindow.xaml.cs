﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Media.Animation;


namespace Animation_Bsp
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Storyboard sb = FindResource("storyboard2") as Storyboard;
            if (sb != null) sb.Begin();
            // if (sb != null) sb.Begin(button2);  Nur wenn kein TargetName angeben wurde!!
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation ani = new DoubleAnimation();
            ani.From = 1;
            ani.To = 0;
            button2.BeginAnimation(Button.OpacityProperty, ani);
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Storyboard sb = FindResource("storyboard3") as Storyboard;
            if (sb != null) sb.Begin(button3);
        }
    }
}
