﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Zeichenprogramm
{
    public partial class Form1 : Form
    {
        enum Figuren : int  { Linie, Ellipse, Rechteck }

        private Figuren Figur = Figuren.Linie;
        private Bitmap bmp;
        private Graphics bckg;
        private Pen p;

        private Point p1;
        private Point p2;

        public Form1()
        {
            InitializeComponent();
            //Size size = this.Size;
            Size maxsize = SystemInformation.PrimaryMonitorMaximizedWindowSize;
            bmp = new Bitmap(maxsize.Width, maxsize.Height);
            bckg = Graphics.FromImage(bmp);
            bckg.Clear(this.BackColor);
            p = new Pen(Color.Black);
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            p1 = e.Location;
        }

        private void Zeichne(Graphics dst)
        {
            switch (Figur)
            {
                case Figuren.Linie:
                    {
                        dst.DrawLine(p, p1, p2);
                        break;
                    }
                case Figuren.Rechteck:
                    {
                        dst.DrawRectangle(p, p1.X, p1.Y, p2.X - p1.X, p2.Y - p1.Y);
                        break;
                    }
                case Figuren.Ellipse:
                    {
                        dst.DrawEllipse(p, p1.X, p1.Y, p2.X - p1.X, p2.Y - p1.Y);
                        break;
                    }

            }

        }


        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            p2 = e.Location;
            if (e.Button == MouseButtons.Left)
            {
                Graphics g = CreateGraphics();
                g.DrawImage(bmp, 0, 0);
                Zeichne(g);
                g.Dispose();
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            Zeichne(bckg);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(bmp, 0, 0);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Figur = Figuren.Linie;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Figur = Figuren.Ellipse;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Figur = Figuren.Rechteck;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            colorDialog1.AllowFullOpen = true;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                 p = new Pen(colorDialog1.Color);
        }
    }
}