﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Dialoge
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = Label1.Font;
            if (fontDialog1.ShowDialog() == DialogResult.OK) Label1.Font = fontDialog1.Font;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
      //      colorDialog2.AllowFullOpen = false;
            colorDialog2.CustomColors = new int[] { 6975964, 231202, 1294476 };

            if (colorDialog2.ShowDialog() == DialogResult.OK) this.BackColor = colorDialog2.Color;
        }
    }
}
