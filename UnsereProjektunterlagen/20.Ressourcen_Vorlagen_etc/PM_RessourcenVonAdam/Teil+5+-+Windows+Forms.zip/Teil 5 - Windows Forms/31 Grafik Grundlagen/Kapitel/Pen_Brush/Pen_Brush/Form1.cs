﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace Pen_Brush
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();

            Pen mypen = new Pen(Color.FromArgb(25, 17, 69, 137), 10);

            g.DrawLine(mypen, 10, 10, 100, 100);
            mypen = new Pen(Color.Red, 15);
            PointF[] punkte = new PointF[] { new PointF(10, 10), new PointF(100, 100), new PointF(50, 150) };


            mypen.EndCap = LineCap.Round;
            mypen.StartCap = LineCap.ArrowAnchor;
            mypen.DashStyle = DashStyle.DashDot;
            mypen.DashCap = DashCap.Round;
            mypen.LineJoin = LineJoin.Round;
            g.DrawLines(mypen, punkte);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            HatchBrush myBrush = new HatchBrush(HatchStyle.SolidDiamond, Color.Black, Color.Yellow);
            g.FillRectangle(myBrush, 10, 10, 200, 100);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Image img = new Bitmap("bitmap1.bmp");

            TextureBrush myBrush = new TextureBrush(img);
            g.FillRectangle(myBrush, 10, 10, 200, 100);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Rectangle rect = new Rectangle(10, 10, 200, 135);
            LinearGradientBrush myBrush = new LinearGradientBrush(rect, Color.Red, Color.Yellow, LinearGradientMode.Vertical);
            g.FillRectangle(myBrush, new Rectangle(10, 10, 200, 185));
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            GraphicsPath path = new GraphicsPath();

            path.AddLine(10, 10, 300, 10);
            path.AddLine(300, 10, 250, 200);
            path.AddLine(250, 200, 150, 250);
            path.AddLine(150, 250, 50, 200);

            PathGradientBrush myBrush = new PathGradientBrush(path);
            Color[] myColors = new Color[] { Color.Yellow, Color.Green, Color.Red, Color.Cyan, Color.Blue };

            myBrush.CenterColor = Color.Blue;
            myBrush.SurroundColors = myColors;
            myBrush.CenterPoint = new PointF(60, 60);
            g.FillPath(myBrush, path);
        }
    }
}
