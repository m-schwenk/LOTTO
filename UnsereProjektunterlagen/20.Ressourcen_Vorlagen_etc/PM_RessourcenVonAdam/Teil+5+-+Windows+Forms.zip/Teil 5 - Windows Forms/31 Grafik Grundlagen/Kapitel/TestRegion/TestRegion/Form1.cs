﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;


namespace TestRegion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();

            Region Reg1 = new Region(new Rectangle(100, 100, 200, 200));
            Region Reg2 = new Region(new Rectangle(50, 50, 150, 150));
            Reg2.Union(Reg1);
            g.SetClip(Reg2, CombineMode.Replace);
            g.DrawImage(PictureBox1.Image, 0, 0);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            SolidBrush blueBrush = new SolidBrush(Color.Blue);
            Region Reg1 = new Region(new Rectangle(100, 100, 200, 200));
            Region Reg2 = new Region(new Rectangle(50, 50, 150, 150));
            Reg2.Xor(Reg1);
            g.FillRegion(blueBrush, Reg2);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            SolidBrush blueBrush = new SolidBrush(Color.Blue);
            Region Reg1 = new Region(new Rectangle(100, 100, 200, 200));
            Region Reg2 = new Region(new Rectangle(50, 50, 150, 150));
            Reg2.Union(Reg1);
            g.FillRegion(blueBrush, Reg2);
        }
    }
}
