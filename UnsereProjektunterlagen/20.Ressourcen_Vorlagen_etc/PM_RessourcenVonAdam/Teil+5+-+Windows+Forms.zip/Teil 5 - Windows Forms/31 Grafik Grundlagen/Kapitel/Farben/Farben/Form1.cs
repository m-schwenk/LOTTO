﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Farben
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Color c1, c2;
            c1 = Color.FromArgb(125, Color.Red);
            g.FillEllipse(new SolidBrush(c1), new Rectangle(10, 10, 150, 100));

            c2 = Color.FromArgb(12, Color.Red);
            g.FillEllipse(new SolidBrush(c2), new Rectangle(50, 50, 250, 200));

            if (c1.ToArgb() == c2.ToArgb()) MessageBox.Show("Beide Farben sind gleich!");
        }
    }
}
