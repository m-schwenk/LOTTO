﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Thumbnail
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Image GetThumb(int size, Image img)
        {
            Single xy;
            xy = (Single)(img.Width / img.Height);
            if (xy > 1)
                return img.GetThumbnailImage(size, (int)(size / xy), null, IntPtr.Zero);
            else
                return img.GetThumbnailImage((int)(size * xy), size, null, IntPtr.Zero);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = GetThumb(80, pictureBox1.Image);
        }
    }
}
