﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Drawing2D;

namespace PathTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            GraphicsPath myPath = new GraphicsPath();

            TextureBrush mybrush = new TextureBrush(SystemIcons.Error.ToBitmap());

            myPath.FillMode = FillMode.Alternate;
            myPath.AddEllipse(10, 10, 200, 100);
            myPath.AddEllipse(100, 50, 278, 170);

            g.FillPath(mybrush, myPath);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            GraphicsPath myPath = new GraphicsPath();

            myPath.AddEllipse(10, 10, 200, 100);
            myPath.AddEllipse(100, 50, 278, 170);
            myPath.AddLine(10, 10, 150, 10);
            myPath.AddLine(150, 10, 200, 100);
       //     myPath.CloseAllFigures();
            g.DrawPath(new Pen(Color.Red, 3), myPath);
            g.FillPath(Brushes.Blue, myPath);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            GraphicsPath myPath = new GraphicsPath();

            myPath.AddEllipse(10, 10, 200, 100);
            myPath.AddEllipse(100, 50, 278, 170);
            myPath.AddLine(10, 10, 150, 10);
            myPath.AddLine(150, 10, 200, 100);

            g.DrawPath(new Pen(Color.Red, 2), myPath);
        }
    }
}
