﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Text;

namespace Zeichenoperationen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            PointF[] punkte = { new PointF(0, 0), new PointF(100, 100), new PointF(20, 80) };
            g.DrawLines(new Pen(Color.Black), punkte);

        }

        private void Button3_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Rectangle[] rec = { new Rectangle(10, 10, 100, 100), new Rectangle(50, 50, 200, 120) };
            g.FillRectangles(new SolidBrush(Color.Red), rec);
        }

        private void Button2_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Point[] Ps = new Point[6];

            Ps[0] = new Point(30, 60);
            Ps[1] = new Point(150, 40);
            Ps[2] = new Point(212, 1);
            Ps[3] = new Point(190, 50);
            Ps[4] = new Point(244, 150);
            Ps[5] = new Point(130, 180);

            g.DrawPolygon(new Pen(Color.Red), Ps);
        }

        private void Button1_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            PointF[] Ps = new PointF[6];

            Single u = 0.6F;

            Ps[0] = new PointF(0, 100);
            Ps[1] = new PointF(100, 0);
            Ps[2] = new PointF(200, 100);
            Ps[3] = new PointF(300, 200);
            Ps[4] = new PointF(400, 100);
            Ps[5] = new PointF(500, 0);

            g.DrawLines(new Pen(Color.Black, 2), Ps);
            g.DrawCurve(new Pen(Color.Red, 2), Ps, 0, 5, u);

        }

        private void Button5_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Point start, Stütz1, stütz2, ende;

            start = new Point(0, 100);
            Stütz1 = new Point(100, 0);
            stütz2 = new Point(200, 200);
            ende = new Point(300, 100);
            g.DrawBezier(new Pen(Color.Black, 2), start, Stütz1, stütz2, ende);
        }

        private void Button6_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Rectangle rec = new Rectangle(10, 10, 150, 100);
            g.DrawEllipse(new Pen(Color.Black, 2), rec);
        }

        private void Button7_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Rectangle rec = new Rectangle(10, 10, 200, 200);
            g.FillPie(new SolidBrush(Color.Red), rec, 0, 100);
            g.FillPie(new SolidBrush(Color.Green), rec, 100, 60);
            g.FillPie(new SolidBrush(Color.Blue), rec, 160, 200);
        }

        private void Button8_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Rectangle rec = new Rectangle(10, 10, 200, 200);
            g.DrawArc(new Pen(Color.Black, 2), rec, 45, 180);
        }


        private void RoundRect(Graphics g, Pen p, Rectangle rect, int x, int y)
        {
            g.DrawArc(p, new Rectangle(rect.Left, rect.Top, 2 * x, 2 * y), 180, 90);
            g.DrawArc(p, new Rectangle(rect.Left + rect.Width - 2 * x, rect.Top, 2 * x, 2 * y), 270, 90);
            g.DrawArc(p, new Rectangle(rect.Left + rect.Width - 2 * x, rect.Top + rect.Height - 2 * y, 2 * x, 2 * y), 0, 90);
            g.DrawArc(p, new Rectangle(rect.Left, rect.Top + rect.Height - 2 * y, 2 * x, 2 * y), 90, 90);
            g.DrawLine(p, rect.Left + x, rect.Top, rect.Right - x, rect.Top);
            g.DrawLine(p, rect.Left + x, rect.Bottom, rect.Right - x, rect.Bottom);
            g.DrawLine(p, rect.Left, rect.Top + y, rect.Left, rect.Bottom - y);
            g.DrawLine(p, rect.Right, rect.Top + y, rect.Right, rect.Bottom - y);
        }


        private void Button9_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            RoundRect(g, new Pen(Color.Black, 3), new Rectangle(10, 10, 250, 150), 20, 10);
        }

        private void Button10_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.DrawString("Textausgabe", new Font("Arial", 12), new SolidBrush(Color.Black), 70, 70);

            SizeF mysize;
            Font myfont = new Font("Arial", 36);
            mysize = g.MeasureString("Textausgabe", myfont);
            g.DrawString("Textausgabe", myfont, new SolidBrush(Color.Black), (this.Width - mysize.Width) / 2, 150);
        }

        private void Button11_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Font myfont = new Font("Arial", 12);

            g.DrawString("Textausgabe im Rechteck", myfont, Brushes.Red, new RectangleF(10, 10, 60, 180));
            g.DrawRectangle(new Pen(Color.Black), new Rectangle(10, 10, 60, 180));
        }

        private void Button12_Click(object sender, System.EventArgs e)
        {
            Graphics g = this.CreateGraphics();

            g.RotateTransform(15);

            g.DrawString("Textausgabe", new Font("Arial", 40), new SolidBrush(Color.Black), 30, 10);
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            g.DrawString("Textausgabe", new Font("Arial", 40), new SolidBrush(Color.Black), 30, 60);
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
            g.DrawString("Textausgabe", new Font("Arial", 40), new SolidBrush(Color.Black), 30, 110);
        }

        private void Button13_Click(object sender, System.EventArgs e)
        {
            Single faktor;
            Graphics g = this.CreateGraphics();

            faktor = PictureBox1.Image.Height / PictureBox1.Image.Width;

            g.DrawImageUnscaled(PictureBox1.Image, 0, 0);
            g.DrawImage(PictureBox1.Image, 30, 30, 100, 100 * faktor);
        }



    }
}
