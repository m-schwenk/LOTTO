﻿namespace Zeichenoperationen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(443, 158);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(224, 136);
            this.PictureBox1.TabIndex = 42;
            this.PictureBox1.TabStop = false;
            // 
            // Button13
            // 
            this.Button13.Location = new System.Drawing.Point(403, 102);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(80, 23);
            this.Button13.TabIndex = 41;
            this.Button13.Text = "DrawImage";
            this.Button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // Button12
            // 
            this.Button12.Location = new System.Drawing.Point(403, 78);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(80, 23);
            this.Button12.TabIndex = 40;
            this.Button12.Text = "Text Antialiasing";
            this.Button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // Button11
            // 
            this.Button11.Location = new System.Drawing.Point(403, 54);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(80, 23);
            this.Button11.TabIndex = 39;
            this.Button11.Text = "Textbox";
            this.Button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // Button10
            // 
            this.Button10.Location = new System.Drawing.Point(403, 30);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(80, 24);
            this.Button10.TabIndex = 38;
            this.Button10.Text = "Text";
            this.Button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(403, 6);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(80, 24);
            this.Button9.TabIndex = 37;
            this.Button9.Text = "RoundRect";
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(323, 174);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(80, 24);
            this.Button8.TabIndex = 36;
            this.Button8.Text = "Arc";
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(323, 150);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(80, 24);
            this.Button7.TabIndex = 35;
            this.Button7.Text = "Pie";
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(323, 126);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(80, 24);
            this.Button6.TabIndex = 34;
            this.Button6.Text = "Kreis/Ellipse";
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(323, 102);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(80, 24);
            this.Button5.TabIndex = 33;
            this.Button5.Text = "Bezier";
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(323, 6);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(80, 23);
            this.Button4.TabIndex = 32;
            this.Button4.Text = "Polyline";
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(323, 30);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(80, 23);
            this.Button3.TabIndex = 31;
            this.Button3.Text = "Rechtecke";
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(323, 54);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(80, 23);
            this.Button2.TabIndex = 30;
            this.Button2.Text = "Polygon";
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(323, 78);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(80, 24);
            this.Button1.TabIndex = 29;
            this.Button1.Text = "Spline";
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 205);
            this.Controls.Add(this.PictureBox1);
            this.Controls.Add(this.Button13);
            this.Controls.Add(this.Button12);
            this.Controls.Add(this.Button11);
            this.Controls.Add(this.Button10);
            this.Controls.Add(this.Button9);
            this.Controls.Add(this.Button8);
            this.Controls.Add(this.Button7);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button1);
            this.Name = "Form1";
            this.Text = "Zeichenoperationen";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Button Button13;
        internal System.Windows.Forms.Button Button12;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
    }
}

