﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = "Das ist ein Text zum Testen!";

            maskedTextBox1.Mask = "999,999.00 $";
        }

        private void maskedTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (maskedTextBox1.MaskCompleted) label1.Text = maskedTextBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           textBox1.Font = new Font(textBox1.Font, FontStyle.Italic);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Font = new Font(textBox1.Font, FontStyle.Regular);
        }

        
    }
}
