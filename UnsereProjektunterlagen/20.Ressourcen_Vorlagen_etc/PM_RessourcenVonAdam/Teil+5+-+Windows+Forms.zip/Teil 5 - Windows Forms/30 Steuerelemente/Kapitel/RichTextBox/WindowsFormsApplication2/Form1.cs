﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Fett
        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, richTextBox1.SelectionFont.Style ^ FontStyle.Bold);
            richTextBox1.Focus();
        }

        // Kursiv
        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, richTextBox1.SelectionFont.Style ^ FontStyle.Italic);
            richTextBox1.Focus();
        }

        // Rot
        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionColor = Color.Red;
        }

        // Größe
        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.Name, Convert.ToSingle(textBox1.Text));
            richTextBox1.Focus();
        }

        // Zentrieren
        private void button7_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
        }

        // Speichern
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox1.SaveFile(Application.StartupPath + "\\test.rtf");
            }
            catch (IOException ioe)
            {
                MessageBox.Show(ioe.Message);
            }
        }

        // Laden
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox1.LoadFile(Application.StartupPath + "\\test.rtf");
            }
            catch (IOException ioe)
            {
                MessageBox.Show(ioe.Message);
            }
        }

       






    }
}
