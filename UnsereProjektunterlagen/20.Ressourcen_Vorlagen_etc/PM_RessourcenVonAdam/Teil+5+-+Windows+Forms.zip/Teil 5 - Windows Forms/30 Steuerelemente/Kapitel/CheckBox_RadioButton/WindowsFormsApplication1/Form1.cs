﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
                textBox1.ReadOnly = true;
            else textBox1.ReadOnly = false;

            if (checkBox7.Checked)
                textBox1.BackColor = Color.Yellow;
            else textBox1.BackColor = Color.White;
        }

        private void checkBox8_Click(object sender, EventArgs e)
        {
            //checkBox8.Checked = !checkBox8.Checked;
            CheckBox cb = (CheckBox)sender;
            cb.Checked = !cb.Checked;
        }

        
    }
}
