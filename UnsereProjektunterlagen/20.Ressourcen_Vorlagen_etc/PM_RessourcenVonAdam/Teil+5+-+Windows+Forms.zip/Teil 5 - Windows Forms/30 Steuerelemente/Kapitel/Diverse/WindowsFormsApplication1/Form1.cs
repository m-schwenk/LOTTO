﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.PasswordChar = '*';
            int lc = 10;
            hScrollBar1.LargeChange = lc;

            numericUpDown1.Maximum = 1000000;
            numericUpDown1.Value = 1387.56M;
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked) this.BackColor = Color.White;
            else if (radioButton2.Checked) this.BackColor = Color.Yellow;
            else if (radioButton3.Checked) this.BackColor = Color.Red;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // checkedListBox1.SetItemChecked(3, true);
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                listBox2.Items.Add(checkedListBox1.CheckedItems[i]);

            string[] monate = 
               { "Januar", "Februar", "März", "April", "Mai", "Juni", 
                 "Juli", "August", "September", "Oktober", "November", "Dezember" };
            comboBox1.Items.AddRange(monate);
            comboBox1.SelectedIndex = 0;
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            this.BackColor = Color.FromArgb(255, e.NewValue, e.NewValue, e.NewValue);
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > 1000) MessageBox.Show("Wertebereichsüberschreitung!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
             progressBar1.Maximum = 100;
             progressBar1.Step = 10;
             progressBar1.PerformStep();
 
        }
    }
}
