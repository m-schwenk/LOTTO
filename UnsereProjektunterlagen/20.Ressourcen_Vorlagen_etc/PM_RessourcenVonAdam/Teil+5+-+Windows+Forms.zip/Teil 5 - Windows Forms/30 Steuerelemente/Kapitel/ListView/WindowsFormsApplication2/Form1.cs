﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Click += new EventHandler(this.commonClick);
            radioButton2.Click += new EventHandler(this.commonClick);
            radioButton3.Click += new EventHandler(this.commonClick);
            radioButton4.Click += new EventHandler(this.commonClick);
        }

        private void commonClick(object sender, System.EventArgs e)
        {
            showListView();
        } 

        private void showListView()
{
	   listView1.Items.Clear();
       listView1.Columns.Clear();
	   if (radioButton1.Checked) listView1.View = View.SmallIcon;
	   if (radioButton2.Checked) listView1.View = View.LargeIcon;
	   if (radioButton3.Checked) listView1.View = View.Details;
	   if (radioButton4.Checked) listView1.View = View.List;    
// Spalten für Items and SubItems definieren:
	   listView1.Columns.Add("", -2, HorizontalAlignment.Left);
	   listView1.Columns.Add("Montag", -2, HorizontalAlignment.Left);
	   listView1.Columns.Add("Dienstag", -2, HorizontalAlignment.Left);
	   listView1.Columns.Add("Mittwoch", -2, HorizontalAlignment.Center);
	   listView1.Columns.Add("Donnerstag", -2, HorizontalAlignment.Left);
	   listView1.Columns.Add("Freitag", -2, HorizontalAlignment.Center);
	   listView1.LabelEdit = true;           // Editieren erlauben:
	   listView1.AllowColumnReorder = true;  // Ändern der Spaltenanordnung erlauben
	   listView1.CheckBoxes = true;
	   listView1.FullRowSelect = true;   
	   listView1.GridLines = true;        
	   listView1.Sorting = SortOrder.Ascending;            
// Schließlich drei Items mit Gruppen von SubItems erzeugen und zur ListView hinzufügen:
	   ListViewItem item1 = new ListViewItem("item1", 0);
	   item1.Checked = true;
	   item1.SubItems.Add("Deutsch");
	   item1.SubItems.Add("Geschichte");
	   item1.SubItems.Add("Mathe");
	   item1.SubItems.Add("Englisch");
	   item1.SubItems.Add("Sport");
	   listView1.Items.Add(item1);

	   ListViewItem item2 = new ListViewItem("item2", 1);
	   item1.Checked = true;
	   item2.SubItems.Add("Mathe");
	   item2.SubItems.Add("Mathe");
	   item2.SubItems.Add("Ethik");
	   item2.SubItems.Add("Informatik");
	   item2.SubItems.Add("");
	   listView1.Items.Add(item2);

	   ListViewItem item3 = new ListViewItem("item3", 2);
	   item3.Checked = true;
	   item3.SubItems.Add("7");
	   item3.SubItems.Add("8");
	   item3.SubItems.Add("9");
	   listView1.Items.Add(item3);  
  }


    }
}
