﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
       
        private const int n = 3;                  // Anzahl der Buttons
        private const int xpos = 10, ypos = 10;   // linke obere Ecke des ersten Buttons

        private Button[] buttons = new Button[n]; // Array, welches Platz für n Buttons bietet

        public Form1()
        {
            InitializeComponent();
            
            // das Button-Array durchlaufen:
            for (int i = 0; i < n; i++)
            {
                buttons[i] = new Button();     // Button erzeugen
                // Eigenschaften zuweisen:
                buttons[i].Bounds = new Rectangle(new Point(xpos + i*100, ypos), new Size(100, 50));
                buttons[i].Text = "Button" + (i+1).ToString();
                // Gemeinsame Ereignisbehandlung zuweisen:
                buttons[i].Click += new EventHandler(button_Click);                
            }
            // Alle Buttons zum Formular hinzufügen:
            this.Controls.AddRange(buttons);  
        }

        // Gemeiensamer Eventhandler für Click-Ereignis:
        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button) sender;
            MessageBox.Show(btn.Text + " wurde geklickt!");
        }


    }
}
