﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             treeView1.BeginUpdate();
             treeView1.Nodes.Clear();

             // Wir fügen den ersten (Root-)Knoten ein:
             treeView1.Nodes.Add("Deutschland");    // Stammelement
            // erste Ebene:
             treeView1.Nodes[0].Nodes.Add("Bayern");
             treeView1.Nodes[0].Nodes.Add("Sachsen");
             treeView1.Nodes[0].Nodes.Add("Thüringen");
            // zweite Ebene:
             treeView1.Nodes[0].Nodes[0].Nodes.Add("München");
             treeView1.Nodes[0].Nodes[0].Nodes.Add("Nürnberg");

             TreeNode n = treeView1.Nodes[0].Nodes[1];
             n.Nodes.Add("Dresden");
             n.Nodes.Add("Leipzig");
             n.Nodes.Add("Chemnitz");

             treeView1.Nodes[0].Nodes[2].Nodes.Add("Erfurt");
             treeView1.Nodes[0].Nodes[2].Nodes.Add("Altenburg");

             treeView1.Sort();
             treeView1.EndUpdate();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            MessageBox.Show(e.Node.Text);
            MessageBox.Show(e.Node.FullPath);
        }
    }
}
