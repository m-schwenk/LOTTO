﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = "Dies ist ein Text zum Testen des Programms!";
        }


        private void CBChanged(object sender, EventArgs e)
        {
            FontStyle ftStyle = FontStyle.Regular;
            if (checkBox1.Checked) ftStyle |= FontStyle.Bold;   // bitweises ODER
            if (checkBox2.Checked) ftStyle |= FontStyle.Italic;
            if (checkBox3.Checked) ftStyle |= FontStyle.Underline;

            textBox1.Font = new Font(textBox1.Font, ftStyle);           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
