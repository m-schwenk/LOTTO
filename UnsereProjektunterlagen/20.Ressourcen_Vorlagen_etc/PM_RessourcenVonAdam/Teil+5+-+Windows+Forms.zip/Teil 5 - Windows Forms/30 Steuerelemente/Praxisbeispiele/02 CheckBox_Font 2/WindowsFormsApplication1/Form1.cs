﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private TextBox tb = new TextBox();           // Verweis auf TextBox 
        private CheckBox[] checkBoxes = null;         // Verweis auf CheckBox-Array
        private int anz = 0;                          // Anzahl der CheckBoxen

        // Initialisiertes Array mit den verwendeten Schriftstilen:
        private FontStyle[] ftStyles = { FontStyle.Regular, FontStyle.Bold, FontStyle.Italic, FontStyle.Underline };
              

        public Form1()
        {
            InitializeComponent();

            this.SuspendLayout();

            // TextBox erzeugen:
            int xpos = 25, ypos = 10;         // linke obere Ecke der TextBox
            tb.Location = new Point(xpos, ypos);
            tb.Multiline = true;
            tb.Width = 200; tb.Height = 40;
            this.Controls.Add(tb);             // TextBox zum Formular hinzufügen

            // alle CheckBoxen erzeugen:
            anz = ftStyles.Length-1;
            checkBoxes = new CheckBox[anz];
            
            for (int i = 0; i < anz; i++)
            {
                checkBoxes[i] = new CheckBox();
                checkBoxes[i].Location = new Point(xpos, ypos + 50 + i * 25);
                checkBoxes[i].Text = ftStyles[i+1].ToString();
                // Ereignisbehandlung zuweisen:
                checkBoxes[i].CheckedChanged += new EventHandler(CBChanged);                
            }

            this.Controls.AddRange(checkBoxes);  // alle CheckBoxen zum Formular hinzufügen

            tb.Text = "Dies ist ein Text zum Testen des Programms!";

            this.ResumeLayout();
        }

        // Ereignisbehandlung für alle CheckBoxen:
        private void CBChanged(object sender, EventArgs e)
        {
            
            FontStyle ftStyle = ftStyles[0];          // zunächst normalen Schriftstil einstellen

            for (int i = 0; i < anz; i++)             // alle CheckBoxen durchlaufen
            {
                CheckBox cb = checkBoxes[i]; 
                if (cb.Checked)
                    ftStyle |= ftStyles[i + 1];       // Schriftstil durch bitweises ODER zusammensetzen             
            }
            tb.Font = new Font(tb.Font, ftStyle);     // neues Font-Objekt erzeugen und der TextBox zuweisen
        }
    }
}