﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;     // wegen IList

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Initialisierung mit dem Wurzelknoten (Form1):
            this.treeView1.Nodes.Add(this.Name);
            // Array zum Speichern der Knoten (pro Control ein Knoten):
            TreeNode[] nodesForm = new TreeNode[this.Controls.Count];
            // this.treeView1.Nodes[0].ImageIndex = 0;
            // übrige Knoten erzeugen:
            this.setNodes(this.Controls, this.treeView1.Nodes[0]);
        }       

        // alle Controls des Formulars werden durchlaufen und der TreeView wird aufgebaut:
        private void setNodes(IList controls, TreeNode node)
        {
            foreach (Control ctrl in controls)
            {
                int index = node.Nodes.Add(new TreeNode(ctrl.Name));

                setImage(node, ctrl, index);   // das richtige Icon zuordnen

                if (ctrl.Controls.Count > 0)
                {
                    setNodes(ctrl.Controls, node.Nodes[index]);    // rekursiver Aufruf!
                }
            }
        }

        // das zum Control passende Icon wird aus der ImageList geladen und beschriftet:
        private static void setImage(TreeNode node, Control ctrl, int index)
        {

            if (ctrl is GroupBox)
            {
                node.Nodes[index].ImageIndex = 1;
                node.Nodes[index].Text = ctrl.Name + " (GroupBox)";
            }
            else if (ctrl is Panel)
            {
                node.Nodes[index].ImageIndex = 2;
                node.Nodes[index].Text = ctrl.Name + " (Panel)";
            }
            else if (ctrl is Button)
            {
                node.Nodes[index].ImageIndex = 3;
                node.Nodes[index].Text = ctrl.Name + " (Button)";
            }
            else if (ctrl is TextBox)
            {
                node.Nodes[index].ImageIndex = 4;
                node.Nodes[index].Text = ctrl.Name + " (TextBox)";
            }
            else if (ctrl is Label)
            {
                node.Nodes[index].ImageIndex = 5;
                node.Nodes[index].Text = ctrl.Name + " (Label)";
            }
            else if (ctrl is CheckBox)
            {
                node.Nodes[index].ImageIndex = 6;
                node.Nodes[index].Text = ctrl.Name + " (CheckBox)";
            }
            else if (ctrl is RadioButton)
            {
                node.Nodes[index].ImageIndex = 7;
                node.Nodes[index].Text = ctrl.Name + " (RadioButton)";
            }
            else if (ctrl is ListBox)
            {
                node.Nodes[index].ImageIndex = 8;
                node.Nodes[index].Text = ctrl.Name + " (ListBox)";
            }
            else if (ctrl is ComboBox)
            {
                node.Nodes[index].ImageIndex = 9;
                node.Nodes[index].Text = ctrl.Name + " (ComboBox)";
            }
            else if (ctrl is TreeView)
            {
                node.Nodes[index].ImageIndex = 10;
                node.Nodes[index].Text = ctrl.Name + " (TreeView)";
            }          

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
