﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GDI_3D
{
    public partial class Form1 : Form
    {
        c3D my3DSystem = new c3D();
        object cmd;


        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);   // für Zeichnen ist Programmierer und nicht das BS verantwortlich
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);  // keine Message zum Löschen des Hintergrunds
            SetStyle(ControlStyles.DoubleBuffer, true);  // alle Zeichenoperationen werden zunächst im Puffer ausgeführt
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            my3DSystem.AddObject(new point3D(0, 0, 0));
            my3DSystem.AddObject(new coordinateSystem3D(3));
            my3DSystem.AddObject(new line3D(-2, 1, 2, 1, 1, 2));
            my3DSystem.AddObject(new line3D(-2, 1, 2, -2, -1, 2));
            my3DSystem.AddObject(new line3D(-2, -1, 2, 1, -1, 2));
            my3DSystem.AddObject(new line3D(1, -1, 2, 1, 1, 2));
            my3DSystem.AddObject(new line3D(-2, 1, -1, 1, 1, -1));
            my3DSystem.AddObject(new line3D(-2, 1, -1, -2, -1, -1));
            my3DSystem.AddObject(new line3D(-2, -1, -1, 1, -1, -1));
            my3DSystem.AddObject(new line3D(1, -1, -1, 1, 1, -1));
            my3DSystem.AddObject(new line3D(-2, 1, -1, -2, 1, 2));
            my3DSystem.AddObject(new line3D(-2, -1, -1, -2, -1, 2));
            my3DSystem.AddObject(new line3D(1, -1, -1, 1, -1, 2));
            my3DSystem.AddObject(new line3D(1, 1, -1, 1, 1, 2));
            my3DSystem.AddObject(new line3D(-2, 1, -1, -0.5f, 2, -1));
            my3DSystem.AddObject(new line3D(-2, 1, 2, -0.5f, 2, 2));
            my3DSystem.AddObject(new line3D(1, 1, -1, -0.5f, 2, -1));
            my3DSystem.AddObject(new line3D(1, 1, 2, -0.5f, 2, 2));
            my3DSystem.AddObject(new line3D(-0.5f, 2, 2, -0.5f, 2, -1));
            my3DSystem.AddObject(new line3D(1, -0.5f, 0.5f, 1, -0.5f, -0.5f));
            my3DSystem.AddObject(new line3D(1, 0.5f, 0.5f, 1, 0.5f, -0.5f));
            my3DSystem.AddObject(new line3D(1, -0.5f, 0.5f, 1, 0.5f, 0.5f));
            my3DSystem.AddObject(new line3D(1, -0.5f, -0.5f, 1, 0.5f, -0.5f));
            my3DSystem.AddObject(new line3D(-0.5f, 0.5f, -1, 0.5f, 0.5f, -1));
            my3DSystem.AddObject(new line3D(-0.5f, 0.5f, -1, -0.5f, -1, -1));
            my3DSystem.AddObject(new line3D(0.5f, 0.5f, -1, 0.5f, -1, -1));
            my3DSystem.Scale(50);

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            my3DSystem.Draw(e.Graphics);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch ( (cmd as Button).Text)
            {
                case "+":
                    my3DSystem.Scale(1.1f);
                    break;
                case "-":
                    my3DSystem.Scale(0.9f);
                    break;
                case "x-":
                    my3DSystem.Translate(-2,0,0);
                    break;
                case "x+":
                    my3DSystem.Translate(2,0,0);
                    break;
                case "y-":
                    my3DSystem.Translate(0, -2, 0);
                    break;
                case "y+":
                    my3DSystem.Translate(0, 2, 0);
                    break;
                case "z-":
                    my3DSystem.Translate(0, 0, -2);
                    break;
                case "z+":
                    my3DSystem.Translate(0, 0, 2);
                    break;

                case "X-":
                    my3DSystem.Rotate(-1, 0, 0);
                    break;
                case "X+":
                    my3DSystem.Rotate(1, 0, 0);
                    break;
                case "Y-":
                    my3DSystem.Rotate(0, -1, 0);
                    break;
                case "Y+":
                    my3DSystem.Rotate(0, 1, 0);
                    break;
                case "Z-":
                    my3DSystem.Rotate(0, 0, -1);
                    break;
                case "Z+":
                    my3DSystem.Rotate(0, 0, 1);
                    break;
                default:
                    break;
            }
            this.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            cmd = sender;
            timer1.Start();
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            
            timer1.Stop();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            timer1.Interval = trackBar1.Value;
        }
    }
}