﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Drawing;


namespace GDI_3D
{
    struct punkt3D
    {
        public Double x, y, z;
        public PointF OnScreen;
    }

    abstract class Objects3D
    {
        public punkt3D[] points;
        public String Name;
        abstract public void Draw(Graphics g, Pen p);
    }

    class line3D : Objects3D
    {
        public line3D(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            points = new punkt3D[2];
            points[0].x = x1;
            points[0].y = y1;
            points[0].z = z1;
            points[1].x = x2;
            points[1].y = y2;
            points[1].z = z2;
            Name = "line3D";
        }

        override public void Draw(Graphics g, Pen p)
        {
            g.DrawLine(p, points[0].OnScreen, points[1].OnScreen);
        }
    }

    class point3D : Objects3D
    {
        public point3D(double x1, double y1, double z1)
        {
            points = new punkt3D[1];
            points[0].x = x1;
            points[0].y = y1;
            points[0].z = z1;
            Name = "point3D";
        }

        override public void Draw(Graphics g, Pen p)
        {
            g.FillEllipse(Brushes.Red, points[0].OnScreen.X - 3, points[0].OnScreen.Y - 3, 6, 6); 
        }
    }

    class coordinateSystem3D : Objects3D
    {
        public coordinateSystem3D(double size)
        {
            points = new punkt3D[6];
            points[0].x = -size;
            points[0].y = 0;
            points[0].z = 0;
            points[1].x = size;
            points[1].y = 0;
            points[1].z = 0;
            points[2].x = 0;
            points[2].y = -size;
            points[2].z = 0;
            points[3].x = 0;
            points[3].y = size;
            points[3].z = 0;
            points[4].x = 0;
            points[4].y = 0;
            points[4].z = -size;
            points[5].x = 0;
            points[5].y = 0;
            points[5].z = size;
            Name = "coordinateSystem3D";
        }

        override public void Draw(Graphics g, Pen p)
        {
            g.DrawLine(Pens.Red, points[0].OnScreen, points[1].OnScreen);
            g.DrawString("+x", new Font("Arial", 8), Brushes.Red, points[1].OnScreen);
            g.DrawString("-x", new Font("Arial", 8), Brushes.Red, points[0].OnScreen);
            g.DrawLine(Pens.Red, points[2].OnScreen, points[3].OnScreen);
            g.DrawString("+y", new Font("Arial", 8), Brushes.Red, points[3].OnScreen);
            g.DrawString("-y", new Font("Arial", 8), Brushes.Red, points[2].OnScreen);
            g.DrawLine(Pens.Red, points[4].OnScreen, points[5].OnScreen);
            g.DrawString("+z", new Font("Arial", 8), Brushes.Red, points[5].OnScreen);
            g.DrawString("-z", new Font("Arial", 8), Brushes.Red, points[4].OnScreen);
        }
    }


    class c3D
    {
        // Hier allgemeine Optionen
        public double Abstand = 1000;
        public Double links = 200;
        public Double oben = 200;

        public Pen Stift1 = Pens.Black;
        public Pen Stift2 = Pens.Red;

        private double r =  Math.PI / 180;
        private Double[] sint = new Double[3];
        private Double[] cost = new Double[3];
        
        private List<Objects3D> objectList = new List<Objects3D>();
       

        public c3D()
        {
            for (int i = -1; i < 2; i++)
            {
                sint[i + 1] = Math.Sin(i * r * 2);
                cost[i + 1] = Math.Cos(i * r * 2);
            }
        }

        public void AddObject(Objects3D o)
        {
            objectList.Add(o);
        }



        public void ListAll()
        { 
            foreach (Objects3D o3d in objectList)
            {
                Debug.Print(o3d.Name);
                for (int i = 0 ; i < o3d.points.Length; i++)
                    Debug.Print(o3d.Name + ".point[" + i + "]" );    
            }
        }

        public void Scale(double f)
        {
            foreach (Objects3D o3d in objectList)
            {
                for (int i = 0; i < o3d.points.Length; i++)
                {
                   o3d.points[i].x *= f;
                   o3d.points[i].y *= f;
                   o3d.points[i].z *= f;
               }
            }
        }


        public void Translate(double x, double y, double z)
        {
            foreach (Objects3D o3d in objectList)
            {
                for (int i = 0; i < o3d.points.Length; i++)
                {
                    o3d.points[i].x += x;
                    o3d.points[i].y += y;
                    o3d.points[i].z += z;
                }
            }
        }

        public void Rotate(int alpha, int beta, int gamma)
        {
            punkt3D ph;
            // Offsetkorrektur für Arrays beachten

            if (alpha != 0)
            {
                alpha++;
                foreach (Objects3D o3d in objectList)
                {
                    for (int i = 0; i < o3d.points.Length; i++)
                    {
                        ph = o3d.points[i];
                        o3d.points[i].y = o3d.points[i].y * cost[alpha] - o3d.points[i].z * sint[alpha];
                        o3d.points[i].z = ph.y * sint[alpha] + o3d.points[i].z * cost[alpha];
                    }
                }
            }
            if (beta != 0)
            {
                beta++;
                foreach (Objects3D o3d in objectList)
                {
                    for (int i = 0; i < o3d.points.Length; i++)
                    {
                        ph = o3d.points[i];
                        o3d.points[i].z = o3d.points[i].z * cost[beta] - o3d.points[i].x * sint[beta];
                        o3d.points[i].x = ph.z * sint[beta] + o3d.points[i].x * cost[beta];
                    }
                }
            }

            if (gamma != 0)
            {
                gamma++;
                foreach (Objects3D o3d in objectList)
                {
                    for (int i = 0; i < o3d.points.Length; i++)
                    {
                        ph = o3d.points[i];
                        o3d.points[i].x = o3d.points[i].x * cost[gamma] - o3d.points[i].y * sint[gamma];
                        o3d.points[i].y = ph.x * sint[gamma] + o3d.points[i].y * cost[gamma];
                    }
                }
            }
        }


        public void Draw(Graphics g)
        {
            g.DrawLine(Pens.LightYellow, 200, 10, 200, 400);
            g.DrawLine(Pens.LightYellow, 10, 200, 400, 200);
            foreach (Objects3D o3d in objectList)
            {
               for (int i = 0; i < o3d.points.Length; i++)
                   o3d.points[i].OnScreen = new PointF(Convert.ToSingle(o3d.points[i].x * Abstand / (Abstand + o3d.points[i].z) + links),
                                                Convert.ToSingle(-o3d.points[i].y * Abstand / (Abstand + o3d.points[i].z) + oben));
               o3d.Draw(g, Stift1);
            }
        }


    }
}
