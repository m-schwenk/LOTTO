﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace GDI_Matrix
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Matrix m = new Matrix(Convert.ToSingle(textBox1.Text), Convert.ToSingle(textBox2.Text),
                                  Convert.ToSingle(textBox3.Text), Convert.ToSingle(textBox4.Text),
                                  Convert.ToSingle(textBox5.Text), Convert.ToSingle(textBox6.Text));

            
            Graphics g = this.CreateGraphics();
            g.Clear(this.BackColor);
            g.DrawRectangle(Pens.Red, 10, 10, 50, 100);
            g.Transform = m;
            g.DrawLine(Pens.Red, 0, 0, 200, 0);
            g.DrawLine(Pens.Red, 0, 0, 0, 200);
            g.DrawRectangle(Pens.Black, 10, 10, 50, 100);
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Matrix m;
            if (comboBox1.SelectedIndex == 0) return;
            if (comboBox1.SelectedIndex == 1)
            {
                m = new Matrix(1, 0,
                                      0, 1,
                                      0, 0);
            }
            else
            {
                m = new Matrix(Convert.ToSingle(textBox1.Text), Convert.ToSingle(textBox2.Text),
                                      Convert.ToSingle(textBox3.Text), Convert.ToSingle(textBox4.Text),
                                      Convert.ToSingle(textBox5.Text), Convert.ToSingle(textBox6.Text));
            }
            Graphics g = this.CreateGraphics();
            g.Clear(this.BackColor);
            g.DrawRectangle(Pens.Red, 10, 10, 50, 100);
            switch (comboBox1.SelectedIndex)
            {
              case 0: 
                  break;
              case 1:   // Reset
                  break;
              case 2:   // Rot 15
                  m.Rotate(15); 
                  break;
              case 3:   // Rot 45
                  m.Rotate(45);
                  break;
              case 4:
                  m.Shear(0.1f, 0);
                  break;
              case 5:
                  m.Shear(0, 0.1f);
                  break;
              case 6:
                  m.Translate(5, 0);  
                  break;
              case 7:
                  m.Translate(0, 5);
                  break;
              case 8:
                  m.Scale(2, 0);  
                  break;
              case 9:
                  m.Scale(0, 2);
                  break;
              default:
                    break;
            }
            textBox1.Text = m.Elements[0].ToString();
            textBox2.Text = m.Elements[1].ToString();
            textBox3.Text = m.Elements[2].ToString();
            textBox4.Text = m.Elements[3].ToString();
            textBox5.Text = m.Elements[4].ToString();
            textBox6.Text = m.Elements[5].ToString();
            g.Transform = m;
            g.DrawLine(Pens.Red, 0, 0, 200, 0);
            g.DrawLine(Pens.Red, 0, 0, 0, 200);
            g.DrawRectangle(Pens.Black, 10, 10, 50, 100);
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}