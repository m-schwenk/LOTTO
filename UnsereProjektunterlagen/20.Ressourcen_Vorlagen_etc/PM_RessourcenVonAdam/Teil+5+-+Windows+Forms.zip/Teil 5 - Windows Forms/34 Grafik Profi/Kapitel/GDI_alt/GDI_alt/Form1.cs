﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;

namespace GDI_alt
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        private static extern int GetDC(int hwnd);

        [DllImport("user32.dll")]
        private static extern int ReleaseDC(int hwnd, int hdc);

        [DllImport("gdi32.dll")]
        private static extern int CreatePen(int nPenStyle, int nWidth, int crColor);

        [DllImport("gdi32.dll")]
        private static extern int SelectObject(int hdc, int hObject);

        [DllImport("gdi32.dll")]
        private static extern int SetPixel(int hdc, int x, int y, int crColor);

        [DllImport("gdi32.dll")]
        private static extern int LineTo(int hdc, int x, int y);

        [DllImport("gdi32.dll")]
        private static extern int DeleteObject(int hObject);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int dc, hp, ho, dx, dy, i, l;
            Random rnd = new Random();
            dc = GetDC(0);
            dx = 1000;
            dy = 500;
            hp = CreatePen(0, 10, 0);
            ho = SelectObject(dc, hp);
            for (i = 0; i < 50; i++)
            {
                l = SetPixel(dc, rnd.Next(dx), rnd.Next(dy), 0);
                l = LineTo(dc, rnd.Next(dx), rnd.Next(dy));
            }
            DeleteObject(SelectObject(dc, ho));
            ReleaseDC(0, dc);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g;
            IntPtr mydc;
            g = this.CreateGraphics();     // Graphics-Objekt erzeugen
            mydc = g.GetHdc();             // DC abfragen
            LineTo((int)mydc, 0, 0);            // GDI-Funktionen verwenden ... 
            LineTo((int)mydc, 100, 100);
            g.ReleaseHdc(mydc);            // DC freigeben 
        }
    }
}