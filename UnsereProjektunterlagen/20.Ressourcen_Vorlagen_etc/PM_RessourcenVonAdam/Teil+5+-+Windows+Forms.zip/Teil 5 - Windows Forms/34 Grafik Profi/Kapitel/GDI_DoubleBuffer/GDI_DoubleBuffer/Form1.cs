﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GDI_DoubleBuffer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);   // für Zeichnen ist Programmierer und nicht das BS verantwortlich
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);  // keine Message zum Löschen des Hintergrunds
            SetStyle(ControlStyles.DoubleBuffer, true);  // alle Zeichenoperationen werden zunächst im Puffer ausgeführt
            Bitmap bmp = new Bitmap(ClientRectangle.Width, ClientRectangle.Height);
            pictureBox1.Image = bmp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double von = System.Environment.TickCount;
            Graphics g = this.CreateGraphics();
            for (int i = 0; i < 800; i++)
            {
                g.DrawLine(Pens.Red, 0, i, 400, i);
                g.DrawLine(Pens.Blue, 0, 0, 400, i);
                g.DrawLine(Pens.Green, 400, 0, 0, i);

            }
            g.Dispose();
            double bis = System.Environment.TickCount;
            label1.Text = ((bis - von) / 1000).ToString() + " s";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double von = System.Environment.TickCount;

            Bitmap bmp = new Bitmap(ClientRectangle.Width, ClientRectangle.Height);
            Graphics g = Graphics.FromImage(bmp);
            for (int i = 0; i < 800; i++)
            {
                g.DrawLine(Pens.Red, 0, i, 400, i);
                g.DrawLine(Pens.Blue, 0, 0, 400, i);
                g.DrawLine(Pens.Green, 400, 0, 0, i);
            }
            g.Dispose();
            g = this.CreateGraphics();
            g.DrawImage(bmp, 0, 0);
            g.Dispose();
            bmp.Dispose();
            double bis = System.Environment.TickCount;
            label1.Text = ((bis - von) / 1000).ToString() + " s";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double von = System.Environment.TickCount;
            Graphics g = Graphics.FromImage(pictureBox1.Image);
            for (int i = 0; i < 800; i++)
            {
                g.DrawLine(Pens.Red, 0, i, 400, i);
                g.DrawLine(Pens.Blue, 0, 0, 400, i);
                g.DrawLine(Pens.Green, 400, 0, 0, i);
            }
            g.Dispose();
            pictureBox1.Invalidate();
            double bis = System.Environment.TickCount;
            label1.Text = ((bis - von) / 1000).ToString() + " s";

        }

        private void button4_Click(object sender, EventArgs e)
        {
        }
    }
}