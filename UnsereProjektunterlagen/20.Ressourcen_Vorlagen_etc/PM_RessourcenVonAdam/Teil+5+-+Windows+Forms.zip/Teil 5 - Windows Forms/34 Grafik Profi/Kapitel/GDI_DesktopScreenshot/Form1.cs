using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Runtime.InteropServices;    // !!!

namespace Screenshot
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox1.Location = new System.Drawing.Point(168, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(272, 240);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(8, 40);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(152, 32);
            this.Button2.TabIndex = 4;
            this.Button2.Text = "Anzeige in Picturebox";
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(8, 8);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(152, 32);
            this.Button1.TabIndex = 3;
            this.Button1.Text = "Speichern in Datei";
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(8, 216);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 32);
            this.button3.TabIndex = 6;
            this.button3.Text = "Beenden";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(448, 253);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button1);
            this.Name = "Form1";
            this.Text = "... einen Desktop-Screenshot erzeugen?";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
    internal System.Windows.Forms.Button Button2;
    internal System.Windows.Forms.Button Button1;
	private System.Windows.Forms.Button button3;
		internal System.Windows.Forms.PictureBox pictureBox1;

// -------------------------------------------------------------------------

    private const int SRCCOPY = 0xCC0020;

    [DllImport("gdi32.dll")]
    private  static extern int  BitBlt(IntPtr  hDestDC,int  x,int  y,int  nWidth,
      int  nHeight,IntPtr  hSrcDC,int  xSrc,int  ySrc,int  dwRop);

    [DllImport("user32.dll")]
    private  static extern IntPtr  GetDC(int  hwnd);

    [DllImport("user32.dll")]
    private  static extern int  ReleaseDC(int  hwnd,IntPtr hdc);


	// Speichern in Datei:
    private void Button1_Click(object sender, System.EventArgs e)
    {
      Graphics g1;
      IntPtr dc1, dc2;
      Image img;
      
      this.Visible = false;

      img = new Bitmap(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
      g1 = Graphics.FromImage(img);

      dc1 = GetDC(0);
      dc2 = g1.GetHdc();
      BitBlt(dc2, 0, 0, Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height, dc1, 0, 0, SRCCOPY);
      ReleaseDC(0, dc1);
      g1.ReleaseHdc(dc1);
      img.Save("c:\\Form1.png", System.Drawing.Imaging.ImageFormat.Png);
      MessageBox.Show("Desktop-Screenshot gesichert", "Info");
      this.Visible = true;
    }

		// Anzeige in PictureBox:
    private void Button2_Click(object sender, System.EventArgs e)
    {
      Graphics g1;
      IntPtr dc1, dc2;
      
      
      this.Visible = false;
      Image img = new Bitmap(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
      g1 = Graphics.FromImage(img);

      dc1 = GetDC(0);
      dc2 = g1.GetHdc();
      BitBlt(dc2, 0, 0, Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height, dc1, 0, 0, SRCCOPY);
      ReleaseDC(0, dc1);
      g1.ReleaseHdc(dc1);
      pictureBox1.Image = img;
      this.Visible = true;
    }

		// Beenden:
		private void button3_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
