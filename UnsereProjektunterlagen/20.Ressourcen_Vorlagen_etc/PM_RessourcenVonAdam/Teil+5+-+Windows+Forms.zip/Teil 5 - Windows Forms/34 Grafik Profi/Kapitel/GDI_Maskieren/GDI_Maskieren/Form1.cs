﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GDI_Maskieren
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap bmp1 = global::GDI_Maskieren.Properties.Resources._1;
            Graphics g = this.CreateGraphics();
            bmp1.MakeTransparent(bmp1.GetPixel(2, 2));
            g.DrawImage(bmp1, new Rectangle(50,50,180,180));
            g.Dispose();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap bmp1 = global::GDI_Maskieren.Properties.Resources._2;
            Graphics g = this.CreateGraphics();
            g.DrawImage(bmp1, 0, 0);
            g.Dispose();

        }
    }
}