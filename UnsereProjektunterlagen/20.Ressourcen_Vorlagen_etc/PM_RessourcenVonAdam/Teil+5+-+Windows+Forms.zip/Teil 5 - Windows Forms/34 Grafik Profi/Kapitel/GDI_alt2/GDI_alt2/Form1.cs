﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace GDI_alt2
{
    public partial class Form1 : Form
    {
        private const int MM_ISOTROPIC = 7;

        [DllImport("gdi32.dll")]
        private static extern int SetMapMode(IntPtr hdc, int nMapMode);

        [DllImport("gdi32.dll")]
        private static extern int SetWindowExtEx(IntPtr hdc, int nX, int nY, int lpSize);

        [DllImport("gdi32.dll")]
        private static extern int SetViewportExtEx(IntPtr hdc, int nX, int nY, int lpSize);

        [DllImport("gdi32.dll")]
        private static extern int Rectangle(IntPtr hdc, int X1, int Y1, int X2, int Y2);

        [DllImport("user32.dll")]
        private static extern IntPtr GetDC(IntPtr hwnd);

        [DllImport("user32.dll")]
        private static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINTAPI
        {
            public int x;
            public int y;
        }

        private const int MM_ANISOTROPIC = 8;

        [DllImport("gdi32.dll")]
        private static extern int LineTo(IntPtr hdc, int x, int y);

        [DllImport("gdi32.dll")]
        private static extern int SetWindowOrgEx(IntPtr hdc, int nX, int nY,
                 [MarshalAs(UnmanagedType.Struct)] ref  POINTAPI lpPoint);

        [DllImport("gdi32.dll")]
        private static extern int MoveToEx(IntPtr hdc, int x, int y,
                 [MarshalAs(UnmanagedType.Struct)] ref  POINTAPI lpPoint);


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IntPtr mydc;
            mydc = GetDC(this.Handle);
            SetMapMode(mydc, MM_ISOTROPIC);
            SetWindowExtEx(mydc, 4000, 4000, 0);
            SetViewportExtEx(mydc, this.ClientSize.Width, this.ClientSize.Height, 0);
            Rectangle(mydc, 0, 0, 4000, 4000);    // ... zeigt die Größe der Zeichnung
            ReleaseDC(this.Handle, mydc);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            IntPtr mydc;
            POINTAPI p;
            int i;
            Single max;
            p.x = 0; p.y = 0;
            mydc = GetDC(this.Handle);
            max = (int)(2 * 3.1415926 * 100);
            SetMapMode(mydc, MM_ANISOTROPIC);
            SetWindowExtEx(mydc, (int)max, 200, 0);
            SetViewportExtEx(mydc, this.ClientSize.Width, -this.ClientSize.Height, 0);
            SetWindowOrgEx(mydc, 0, 100, ref p);   // Verschiebung Nullpunkt
            MoveToEx(mydc, 0, 0, ref p);
            for (i = 0; i <= max; i++)
                LineTo(mydc, i, (int)(100 * Math.Sin(i / 100f)));
            ReleaseDC(this.Handle, mydc);
        }
    }
}