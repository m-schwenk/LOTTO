﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GDI_Animation
{

    public partial class Form1 : Form
    {

        Bitmap bmp1 = Properties.Resources.bird;
        Bitmap bmp2 = GDI_Animation.Properties.Resources.ballon;
        Bitmap bmp3 = GDI_Animation.Properties.Resources.airplan;
        Bitmap bckbmp = GDI_Animation.Properties.Resources.background;
        int pos;

        public Form1()
        {
            InitializeComponent();

            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer , true);
//            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
//            SetStyle(ControlStyles.DoubleBuffer, true);
            if (ImageAnimator.CanAnimate(bmp1)) ImageAnimator.Animate(bmp1, null);
        }        

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }



        protected override void OnPaint(PaintEventArgs e)
        {
           // base.OnPaint(e);
            e.Graphics.DrawImage(bckbmp, 0, 0);
            e.Graphics.DrawImage(bmp3, pos, pos);
            e.Graphics.DrawImage(bmp2, pos, 450 - pos);
            e.Graphics.DrawImage(bmp1, 2 * pos - 100, 200);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pos++;
            ImageAnimator.UpdateFrames();
            if (pos > 500) pos = 0; 
            this.Invalidate();

        }
    }
}