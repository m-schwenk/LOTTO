﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GDI_SaveJPG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ImageCodecInfo myImageCodecInfo = null;
            foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
                if (codec.MimeType == "image/jpeg") myImageCodecInfo = codec;
            EncoderParameters myParameter = new EncoderParameters();
            myParameter.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, comboBox1.SelectedIndex * 25 + 25);
            pictureBox1.Image.Save("Bild.jpg", myImageCodecInfo, myParameter);
        }
    }
}