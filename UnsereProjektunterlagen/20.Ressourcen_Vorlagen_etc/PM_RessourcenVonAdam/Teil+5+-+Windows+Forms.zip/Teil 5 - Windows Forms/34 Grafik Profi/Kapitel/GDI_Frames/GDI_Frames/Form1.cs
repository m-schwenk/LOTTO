﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GDI_Frames
{
    public partial class Form1 : Form
    {
        Bitmap bmp = global::GDI_Frames.Properties.Resources.dino6;
        FrameDimension fdim;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           fdim = new FrameDimension(bmp.FrameDimensionsList[0]);
           trackBar1.Maximum = bmp.GetFrameCount(fdim)-1;

           Bitmap bmp2 = new Bitmap((bmp.GetFrameCount(fdim) - 1) * bmp.Width, bmp.Height);
           Graphics g = Graphics.FromImage(bmp2);
            for (int i = 0; i < bmp.GetFrameCount(fdim); i++)
           {
               bmp.SelectActiveFrame(fdim, i);
               g.DrawImageUnscaled(bmp, i * bmp.Width, 0);
           }

           pictureBox1.Image = bmp2;
           bmp2.Save("c:\\test.bmp");
           g.Dispose();    
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            bmp.SelectActiveFrame(fdim, trackBar1.Value);
            Graphics g = this.CreateGraphics();
            g.Clear(this.BackColor);
            g.DrawImage(bmp,0,0);
        }
    }
}