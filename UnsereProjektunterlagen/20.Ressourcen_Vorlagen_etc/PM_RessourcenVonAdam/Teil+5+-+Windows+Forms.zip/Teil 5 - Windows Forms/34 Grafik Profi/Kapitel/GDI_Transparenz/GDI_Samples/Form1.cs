﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace GDI_Samples
{
    public partial class Form1 : Form
    {
        private Bitmap bmp;

        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
            bmp = global::GDI_Samples.Properties.Resources._0000003550;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            ImageAttributes iattr = new ImageAttributes();
            ColorMatrix m = new ColorMatrix();
            m.Matrix33 = trackBar1.Value / 100f;
            iattr.SetColorMatrix(m);
            e.Graphics.DrawImage(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height), 0, 0, bmp.Width, bmp.Height, GraphicsUnit.Pixel, iattr);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}