﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GDI_AnimGIF
{
    public partial class Form1 : Form
    {
        Bitmap bmp2 = Properties.Resources.dino3;
        Bitmap bmp1 = Properties.Resources.dino6;

        private void OnNextFrame(object o, EventArgs e)
        {
            this.Invalidate();
        }


        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
            if (ImageAnimator.CanAnimate(bmp1)) ImageAnimator.Animate(bmp1, this.OnNextFrame);
            if (ImageAnimator.CanAnimate(bmp2)) ImageAnimator.Animate(bmp2, this.OnNextFrame);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            e.Graphics.DrawImage(bmp2, 10, 10);
            e.Graphics.DrawImage(bmp1, 200, 10);
            ImageAnimator.UpdateFrames();
        }


        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}