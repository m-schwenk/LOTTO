﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace GDI_Filter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Filter.Sharpen((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Filter.Smoothing((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Filter.Emboss((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }


        private void Invert(Bitmap b)
        {
            int x, y, offset, lineoffs;
            Byte p;
            IntPtr ptr;

            BitmapData bmpData = b.LockBits(new Rectangle(0, 0, b.Width, b.Height),
                                 ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            ptr = bmpData.Scan0;
            offset = 0;
            lineoffs = bmpData.Stride - b.Width * 3;
            for (y = 0; y < b.Height - 1; y++)
            {
                for (x = 0; x < b.Width * 3 - 1; x++)
                {
                    p = (Byte)(255 - Marshal.ReadByte(ptr, offset));
                    Marshal.WriteByte(ptr, offset, p);
                    offset += 1;
                }
                offset += lineoffs;
            }
            b.UnlockBits(bmpData);
        }


        private void button4_Click(object sender, EventArgs e)
        {
            double von = System.Environment.TickCount;
            Filter.AllesSchwarzTest1((Bitmap)pictureBox1.Image);
            double bis = System.Environment.TickCount;
            label1.Text = ((bis - von) / 1000).ToString() + " s";
            pictureBox1.Invalidate();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Filter.NurBlau((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int x, y;
            Bitmap b1, b2;
            Color mypix;

            b1 = (Bitmap)pictureBox1.Image;
            b2 = new Bitmap(b1.Height, b1.Width);
            for (x = 0; x < b1.Width; x++)
                for (y = 0; y < b1.Height; y++)
                {
                    mypix = b1.GetPixel(x, y);
                    b2.SetPixel(b1.Height - y - 1, x, mypix);
                }
            pictureBox1.Image = b2;
            pictureBox1.Refresh();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Filter.Invert((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            double von = System.Environment.TickCount;
            Filter.Grey((Bitmap)pictureBox1.Image);
            double bis = System.Environment.TickCount;
            label1.Text = ((bis - von) / 1000).ToString() + " s";
            pictureBox1.Invalidate();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Filter.Brightness((Bitmap)pictureBox1.Image,2);
            pictureBox1.Invalidate();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Filter.Brightness((Bitmap)pictureBox1.Image, -2);
            pictureBox1.Invalidate();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Filter.Contrast((Bitmap)pictureBox1.Image, -5);
            pictureBox1.Invalidate();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Filter.Contrast((Bitmap)pictureBox1.Image, 5);
            pictureBox1.Invalidate();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Filter.AutoAdjust((Bitmap)pictureBox1.Image);
            pictureBox1.Invalidate();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Filter.Gamma((Bitmap)pictureBox1.Image,0.5);
            pictureBox1.Invalidate();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            pictureBox1.Load("0000003550.jpg");
        }

        private void button16_Click(object sender, EventArgs e)
        {
        }
    }
}