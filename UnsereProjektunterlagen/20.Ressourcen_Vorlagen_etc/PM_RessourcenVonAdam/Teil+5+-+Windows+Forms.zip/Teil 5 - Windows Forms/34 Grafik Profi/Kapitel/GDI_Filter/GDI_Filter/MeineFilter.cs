﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace GDI_Filter
{

    public static class Filter
    {

        public static void AllesSchwarzTest1(Bitmap bmp)
        {
            int x, y, offset;
            BitmapData bmpData;
            Byte p;
            IntPtr ptr;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            ptr = bmpData.Scan0;
            offset = 0;
            for (y = 0; y < bmp.Height - 1; y++)
            {
                for (x = 0; x < bmp.Width * 3 - 1; x++)
                {
                    p = 0;
                    Marshal.WriteByte(ptr, offset, p);
                    offset += 1;
                }
            }
            bmp.UnlockBits(bmpData);
        }

        public static void AllesSchwarzTest2(Bitmap bmp)
        {
            int x, y;
            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int lineoffs = bmpData.Stride - bmp.Width * 3;

                for (y = 0; y < bmp.Height - 1; y++)
                {
                    for (x = 0; x < bmp.Width * 3 - 1; x++)
                    {
                        ptr[0] = 0;
                        ptr++;
                    }
                    ptr += lineoffs;
                }
            }
            bmp.UnlockBits(bmpData);
        }

        public static void AllesSchwarzTest3(Bitmap bmp)
        {
            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width * 4;
                for (int i = 0; i < size; i++) 
                   ptr[i] = 0;
            }
            bmp.UnlockBits(bmpData);
        }

        public static void AllesSchwarzTest4(Bitmap bmp)
        {
            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                int* ptr = (int*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;
                for (int i = 0; i < size; i++)
                    ptr[i] = 0;
            }
            bmp.UnlockBits(bmpData);
        }


        public static void NurBlau(Bitmap bmp)
        {
            BitmapData bmpData;
            Byte blau;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = (bmp.Height) * (bmp.Width);
                for (int i = 0; i < size; i++)
                {
                    blau = ptr[0];
                    ptr[0] = 0;
                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);
        }

        public static void Invert(Bitmap bmp)
        {
            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width * 4;
                for (int i = 0; i < size; i++)
                    ptr[i] = (byte)(ptr[i]^255);
                //    oder auch 
                //    ptr[i] = (Byte)(255 - ptr[i]);
            }
            bmp.UnlockBits(bmpData);
        }

        public static void Grey(Bitmap bmp)
        {
            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;
                for (int i = 0; i < size; i++)
                {
                    Byte blau = ptr[0];
                    Byte grün = ptr[1];
                    Byte rot = ptr[2];
                    Byte grau = (Byte) ((77 * blau + 151 * grün + 28 * rot) / 256);
                    ptr[0] = ptr[1] = ptr[2] = grau;
                    // oder 
                    // ptr[0] = ptr[1] = ptr[2] = (Byte)((77 * ptr[0] + 151 * ptr[1] + 28 * ptr[2]) / 256);

                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);
        }

        private static byte normiere(int Value)
        {
            if (Value < 0) return 0;
            if (Value > 255) return 255;
            return (byte)Value;
        }

        public static void Brightness(Bitmap bmp, short Value)
        {
            Byte[] ar = new Byte[256];

            //Zunächst die Tabelle berechnen:
            for (int i = 0; i < 256; i++)
                ar[i] = normiere(i + Value);

            BitmapData bmpData;

            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;
                for (int i = 0; i < size; i++)
                {
                    ptr[0] = ar[ptr[0]];
                    ptr[1] = ar[ptr[1]];
                    ptr[2] = ar[ptr[2]];
                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);
        }

        public static void Contrast(Bitmap bmp, Single Value)
        {
            Byte[] ar = new Byte[256];
            Value = 1 + Value / 100;
            
            //Zunächst die Tabelle berechnen:
            for (int i = 0; i < 256; i++)
                ar[i] = normiere((int)((i - 128) * Value) + 128);

            BitmapData bmpData;
            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;
                for (int i = 0; i < size; i++)
                {
                    ptr[0] = ar[ptr[0]];
                    ptr[1] = ar[ptr[1]];
                    ptr[2] = ar[ptr[2]];
                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);

        }

        public static void Gamma(Bitmap bmp, double Value)
        {
            Byte[] ar = new Byte[256];

            //Zunächst die Tabelle berechnen:
            for (int i = 0; i < 256; i++)
                ar[i] = (byte)Math.Min(255, (int)((255.0 * Math.Pow(i / 255.0, 1.0 / Value)) + 0.5));

            BitmapData bmpData;
            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;
                for (int i = 0; i < size; i++)
                {
                    ptr[0] = ar[ptr[0]];
                    ptr[1] = ar[ptr[1]];
                    ptr[2] = ar[ptr[2]];
                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);
        }


        public static void AutoAdjust(Bitmap bmp)
        {
            int[,] ar = new int[256, 3];

            BitmapData bmpData;
            bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* ptr = (byte*)bmpData.Scan0;
                int size = bmp.Height * bmp.Width;

                // Histogramm erzeugen
                for (int i = 0; i < size; i++)
                {
                    ar[ptr[0], 0]++;  // blau
                    ar[ptr[1], 1]++;  // grün
                    ar[ptr[2], 2]++;  // rot
                    ptr += 4;
                }
                // Für alle Farbkanäle
                for (int c = 0; c < 3; c++)
                {
                    // Minimum suchen
                    int i = 0;
                    while (ar[i, c] == 0) i++;
                    int min = i;
                    // Maximum suchen
                    i = 255;
                    while (ar[i, c] == 0) i--;
                    int max = i;

                    // Speizung berechung
                    Single scale = 255 / (Single)(max - min);

                    // neue Tabelle berechnen
                    for (int j = 0; j < 256; j++)
                        ar[j, c] = normiere((int)((j - min) * scale));
                }
                // aufs erste Byte setzen
                ptr = (byte*)bmpData.Scan0;

                for (int i = 0; i < size; i++)
                {
                    ptr[0] = (byte)ar[ptr[0], 0];  // blau
                    ptr[1] = (byte)ar[ptr[1], 1];  // grün
                    ptr[2] = (byte)ar[ptr[2], 2];  // rot
                    ptr += 4;
                }
            }
            bmp.UnlockBits(bmpData);
        }


        public static void Sharpen(Bitmap bmp)
        {
            GrafikFilter gf = new GrafikFilter();
            gf.Teiler = 3;
            gf.Matrix[0, 0] = 0; gf.Matrix[1, 0] = -2; gf.Matrix[2, 0] = 0;
            gf.Matrix[0, 1] = -2; gf.Matrix[1, 1] = 11; gf.Matrix[2, 1] = -2;
            gf.Matrix[0, 2] = 0; gf.Matrix[1, 2] = -2; gf.Matrix[2, 2] = 0;
            gf.Execute(bmp);
        }

        public static void Smoothing(Bitmap bmp)
        {
            GrafikFilter gf = new GrafikFilter();
            gf.Teiler = 8;
            gf.Matrix[0, 0] = 1; gf.Matrix[1, 0] = 1; gf.Matrix[2, 0] = 1;
            gf.Matrix[0, 1] = 1; gf.Matrix[1, 1] = 1; gf.Matrix[2, 1] = 1;
            gf.Matrix[0, 2] = 1; gf.Matrix[1, 2] = 1; gf.Matrix[2, 2] = 1;
            gf.Execute(bmp);
        }

        public static void Emboss(Bitmap bmp)
        {
            GrafikFilter gf = new GrafikFilter();
            gf.Teiler = 1;
            gf.Offset = 127;
            gf.Matrix[0, 0] = -1; gf.Matrix[1, 0] = 0; gf.Matrix[2, 0] = -1;
            gf.Matrix[0, 1] = 0; gf.Matrix[1, 1] = 4; gf.Matrix[2, 1] = 0;
            gf.Matrix[0, 2] = -1; gf.Matrix[1, 2] = 0; gf.Matrix[2, 2] = -1;
            gf.Execute(bmp);
        }

        public static void Gauss(Bitmap bmp)
        {
            GrafikFilter gf = new GrafikFilter();
            gf.Teiler = 16;
            gf.Matrix[0, 0] = 1; gf.Matrix[1, 0] = 2; gf.Matrix[2, 0] = 1;
            gf.Matrix[0, 1] = 2; gf.Matrix[1, 1] = 4; gf.Matrix[2, 1] = 2;
            gf.Matrix[0, 2] = 1; gf.Matrix[1, 2] = 2; gf.Matrix[2, 2] = 1;
            gf.Execute(bmp);
        }
    }


}
