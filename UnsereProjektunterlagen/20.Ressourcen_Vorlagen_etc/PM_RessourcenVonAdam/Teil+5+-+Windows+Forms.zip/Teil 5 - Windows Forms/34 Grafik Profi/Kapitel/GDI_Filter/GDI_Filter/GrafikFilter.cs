﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;

namespace GDI_Filter
{
    public class GrafikFilter
    {
        public int[ , ] Matrix = {{0,0,0},{0,0,0},{0,0,0}} ;
        public int Teiler = 0; 
        public int Offset = 0; 

        public byte normiere(int Value)
        {
            if (Value < 0) return 0;
            if (Value > 255) return 255;
            return (byte)Value;
        }

        public void Execute(Bitmap bmp)
        {
            Bitmap bmpQuelle = (Bitmap)bmp.Clone();
            BitmapData dataQuelle = bmpQuelle.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            BitmapData dataZiel = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
            unsafe
            {
                byte* pByte = (byte*)dataZiel.Scan0 + bmp.Width * 4 + 4;
                byte* pZeile0 = (byte*)dataQuelle.Scan0;
                byte* pZeile1 = (byte*)dataQuelle.Scan0 + bmp.Width * 4;
                byte* pZeile2 = (byte*)dataQuelle.Scan0 + bmp.Width * 8;
                int size = (bmp.Width - 2) * (bmp.Height - 2);
                for (int i = 0; i < size; i++)
                {
                    pByte[0] = normiere((((pZeile0[0] * Matrix[0, 0]) + (pZeile0[4] * Matrix[1, 0]) + (pZeile0[8] * Matrix[2, 0]) +
                                      (pZeile1[0] * Matrix[0, 1]) + (pZeile1[4] * Matrix[1, 1]) + (pZeile1[8] * Matrix[2, 1]) +
                                      (pZeile2[0] * Matrix[0, 2]) + (pZeile2[4] * Matrix[1, 2]) + (pZeile2[8] * Matrix[2, 2])) / Teiler) + Offset);
                    pByte[1] = normiere((((pZeile0[1] * Matrix[0, 0]) + (pZeile0[5] * Matrix[1, 0]) + (pZeile0[9] * Matrix[2, 0]) +
                                (pZeile1[1] * Matrix[0, 1]) + (pZeile1[5] * Matrix[1, 1]) + (pZeile1[9] * Matrix[2, 1]) +
                                (pZeile2[1] * Matrix[0, 2]) + (pZeile2[5] * Matrix[1, 2]) + (pZeile2[9] * Matrix[2, 2])) / Teiler) + Offset);
                    pByte[2] = normiere((((pZeile0[2] * Matrix[0, 0]) + (pZeile0[6] * Matrix[1, 0]) + (pZeile0[10] * Matrix[2, 0]) +
                                (pZeile1[2] * Matrix[0, 1]) + (pZeile1[6] * Matrix[1, 1]) + (pZeile1[10] * Matrix[2, 1]) +
                                (pZeile2[2] * Matrix[0, 2]) + (pZeile2[6] * Matrix[1, 2]) + (pZeile2[10] * Matrix[2, 2])) / Teiler) + Offset);
                    pByte += 4;
                    pZeile0 += 4;
                    pZeile1 += 4;
                    pZeile2 += 4;
                }
            }
            bmp.UnlockBits(dataZiel);
            bmpQuelle.UnlockBits(dataQuelle);
            bmpQuelle.Dispose();
        }

    }
}
