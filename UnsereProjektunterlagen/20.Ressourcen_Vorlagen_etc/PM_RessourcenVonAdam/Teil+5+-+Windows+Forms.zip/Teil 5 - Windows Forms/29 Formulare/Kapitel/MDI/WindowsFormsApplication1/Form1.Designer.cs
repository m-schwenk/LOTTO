﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mDIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fensterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hintereinanderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vertikalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.neuesChildToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minimierenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mDIToolStripMenuItem,
            this.fensterToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(432, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mDIToolStripMenuItem
            // 
            this.mDIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.neuesChildToolStripMenuItem,
            this.minimierenToolStripMenuItem});
            this.mDIToolStripMenuItem.Name = "mDIToolStripMenuItem";
            this.mDIToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.mDIToolStripMenuItem.Text = "MDI";
            // 
            // fensterToolStripMenuItem
            // 
            this.fensterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hintereinanderToolStripMenuItem,
            this.horizontalToolStripMenuItem,
            this.vertikalToolStripMenuItem});
            this.fensterToolStripMenuItem.Name = "fensterToolStripMenuItem";
            this.fensterToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.fensterToolStripMenuItem.Text = "Fenster";
            // 
            // hintereinanderToolStripMenuItem
            // 
            this.hintereinanderToolStripMenuItem.Name = "hintereinanderToolStripMenuItem";
            this.hintereinanderToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.hintereinanderToolStripMenuItem.Text = "Hintereinander";
            this.hintereinanderToolStripMenuItem.Click += new System.EventHandler(this.hintereinanderToolStripMenuItem_Click);
            // 
            // horizontalToolStripMenuItem
            // 
            this.horizontalToolStripMenuItem.Name = "horizontalToolStripMenuItem";
            this.horizontalToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.horizontalToolStripMenuItem.Text = "Horizontal";
            this.horizontalToolStripMenuItem.Click += new System.EventHandler(this.horizontalToolStripMenuItem_Click);
            // 
            // vertikalToolStripMenuItem
            // 
            this.vertikalToolStripMenuItem.Name = "vertikalToolStripMenuItem";
            this.vertikalToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.vertikalToolStripMenuItem.Text = "Vertikal";
            this.vertikalToolStripMenuItem.Click += new System.EventHandler(this.vertikalToolStripMenuItem_Click);
            // 
            // neuesChildToolStripMenuItem
            // 
            this.neuesChildToolStripMenuItem.Name = "neuesChildToolStripMenuItem";
            this.neuesChildToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.neuesChildToolStripMenuItem.Text = "Neues Child";
            this.neuesChildToolStripMenuItem.Click += new System.EventHandler(this.neuesChildToolStripMenuItem_Click);
            // 
            // minimierenToolStripMenuItem
            // 
            this.minimierenToolStripMenuItem.Name = "minimierenToolStripMenuItem";
            this.minimierenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.minimierenToolStripMenuItem.Text = "Minimieren";
            this.minimierenToolStripMenuItem.Click += new System.EventHandler(this.minimierenToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 115);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mDIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fensterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hintereinanderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vertikalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem neuesChildToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minimierenToolStripMenuItem;
    }
}

