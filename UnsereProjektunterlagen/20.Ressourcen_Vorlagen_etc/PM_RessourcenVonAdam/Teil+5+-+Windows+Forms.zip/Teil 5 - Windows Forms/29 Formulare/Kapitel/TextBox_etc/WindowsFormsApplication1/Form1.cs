﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ControlPaint.DrawFocusRectangle(Graphics.FromHwnd(button2.Handle), button2.ClientRectangle);      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Font = new Font("Arial", 16f, FontStyle.Bold | FontStyle.Underline | FontStyle.Italic);
            ControlPaint.DrawFocusRectangle(Graphics.FromHwnd(button2.Handle), button2.ClientRectangle);      
                 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Tag = "Das ist meine Katze!";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(pictureBox1.Tag.ToString());
        }
    }
}
