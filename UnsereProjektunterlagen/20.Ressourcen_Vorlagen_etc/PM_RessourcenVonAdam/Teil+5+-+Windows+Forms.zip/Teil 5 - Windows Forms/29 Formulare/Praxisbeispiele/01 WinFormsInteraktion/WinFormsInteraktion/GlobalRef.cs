using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsInteraktion
{
    internal static class GlobalRef
    {
        public static Form1 g_Form;
    }
}
