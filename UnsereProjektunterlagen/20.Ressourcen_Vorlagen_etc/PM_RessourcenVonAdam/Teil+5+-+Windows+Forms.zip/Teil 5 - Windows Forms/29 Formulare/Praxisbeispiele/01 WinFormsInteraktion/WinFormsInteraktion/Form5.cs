using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsInteraktion
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((this.Owner != null) && (this.Owner.GetType().Name == "Form1"))
                (this.Owner as Form1).machWas();
            else
                throw new InvalidOperationException("Form1 Instanze nicht gesetzt oder ung�ltig!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((this.Owner != null) && (this.Owner.GetType().Name == "Form1"))
                (this.Owner as Form1).lbl1.Text = textBox1.Text;
            else
                throw new InvalidOperationException("Form1 Instanze nicht gesetzt oder ung�ltig!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((this.Owner != null) && (this.Owner.GetType().Name == "Form1"))
                (this.Owner as Form1).btn1.PerformClick();
            else
                throw new InvalidOperationException("Form1 Instanze nicht gesetzt oder ung�ltig!");
        }
    }
}