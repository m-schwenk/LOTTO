using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsInteraktion
{
    public partial class Form3 : Form
    {
        private Form1 m_Form;

        public Form3()
        {
            InitializeComponent();
        }

        internal Form1 Form
        {
            set
            {
                m_Form = value;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (m_Form != null)
                m_Form.machWas();
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (m_Form != null)
                m_Form.lbl1.Text = textBox1.Text;
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (m_Form != null)
                m_Form.btn1.PerformClick();
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

    }
}