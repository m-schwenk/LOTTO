using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsInteraktion
{
    public partial class Form2 : Form
    {

        private Form1 m_Form;

        public Form2(Form1 frm)
        {
            InitializeComponent();
            m_Form = frm;
        }

        // Instanzenmethode in �bergeordneten Formular ausf�hren:
        private void button1_Click(object sender, EventArgs e)
        {
            if (m_Form != null)
                m_Form.machWas();
            else
            throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        // Steuerelement im �bergeordneten Formular setzen:
        private void button2_Click(object sender, EventArgs e)
        {
            if (m_Form != null) 
                m_Form.lbl1.Text = textBox1.Text;
            else
            throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        // Ereignis im �bergeordneten Formular ausl�sen:
        private void button3_Click(object sender, EventArgs e)
        {
            if (m_Form != null)
                m_Form.btn1.PerformClick();
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }
    }
}