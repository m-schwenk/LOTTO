using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsInteraktion
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (GlobalRef.g_Form != null)
                GlobalRef.g_Form.machWas();
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (GlobalRef.g_Form != null)
                GlobalRef.g_Form.lbl1.Text = textBox1.Text;
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (GlobalRef.g_Form != null)
                GlobalRef.g_Form.btn1.PerformClick();
            else
                throw new InvalidOperationException("Form1 Instanz nicht gesetzt!");
        }
    }
}