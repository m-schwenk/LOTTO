﻿using System;
using System.Collections.Generic;   // !
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public List<string> GList;

        public Form1()
        {
            GList = new List<string>();
            GList.Add("Konstruktoraufruf");
            
            InitializeComponent();

            //GList.Add("Ende Konstruktoraufruf");
        }

        private void Form1_Move(object sender, EventArgs e)
        {
            GList.Add("Move-Ereignis");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GList.Add("Load-Ereignis");
        }

        private void Form1_Layout(object sender, LayoutEventArgs e)
        {
            Control c = e.AffectedControl;
           GList.Add ("Layout-Ereignis für " + c.Name );
           
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            GList.Add("Activated-Ereignis");
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            GList.Add( "Paint-Ereignis");
        }      

        private void Form1_Resize(object sender, EventArgs e)
        {
            GList.Add("Resize-Ereignis");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            GList.Add("FormClosing-Ereignis");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            GList.Add("FormClosed-Ereignis");
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            GList.Add("Deactivate-Ereignis");
        }

        // ---------------------------------------------------------------------

        protected override void OnLoad(EventArgs e)
        {
            GList.Add("Überschreiben der OnLoad-Methode");
            base.OnLoad(e);    // Aufruf der Basisklassenmethode (erst dort hier wird Load-Event ausgelöst!)
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            GList.Add("Überschreiben der OnPaint-Methode");
            base.OnPaint(e);   // Aufruf der Basisklassenmethode (erst dort hier wird Paint-Event ausgelöst!)
        }     
        
    }
}
