﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Form1 frm1 = null;

        private void button1_Click(object sender, EventArgs e)
        {
            frm1 = new Form1();
            frm1.Show();
           
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
          
                //foreach (string s in GListobalRef.F1.GList)
                //    listBox1.Items.Add(s);
            listBox1.Items.Add("Ereigniskette in Form1:");
            listBox1.Items.Add("");
                for (int i = 0; i < frm1.GList.Count; i++)
                    listBox1.Items.Add(frm1.GList[i]);
               frm1.GList.Clear();
        }
    }
}
