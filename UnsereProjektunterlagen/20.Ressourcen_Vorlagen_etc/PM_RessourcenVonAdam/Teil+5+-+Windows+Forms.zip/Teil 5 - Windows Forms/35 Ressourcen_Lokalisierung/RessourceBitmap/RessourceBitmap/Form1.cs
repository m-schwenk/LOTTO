using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// nur f�r Var. 2:
using System.Reflection;   
using System.IO;           

namespace RessourceBitmap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Var.1 (einfach):
        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null) pictureBox1.Image.Dispose();
           // pictureBox1.Image = new Bitmap(typeof(Form1), "BeimChef.bmp");
            pictureBox1.Image = new Bitmap(this.GetType(), "BeimChef.bmp");
           
        }

        
        // Var.2 (ausf�hrlich):
        private void button2_Click(object sender, EventArgs e)
        {
            Assembly ass = Assembly.GetExecutingAssembly();
            if (pictureBox1.Image != null) pictureBox1.Image.Dispose();
            Stream strm = ass.GetManifestResourceStream("RessourceBitmap.BeimChef.bmp");
            pictureBox1.Image = new Bitmap(strm);

        }
    }
}