using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Reflection;    // !
using System.IO;            // ! 


namespace EmbeddedRessourcesViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Assembly ass = null;   // globaler Zeiger auf geladene Assembly

        private void loadResources()   // l�dt alle Ressourcen aus ass in ein Stringarray
        {
            string[] resNames = ass.GetManifestResourceNames();
            listBox1.Items.Clear();
            if (resNames.Length > 0)
            {
                listBox1.BeginUpdate();
                foreach (string resName in resNames)
                {
                    listBox1.Items.Add(resName);
                }
                listBox1.EndUpdate();
            }
            Image img = pictureBox1.Image;
            pictureBox1.Image = null;
            if (img != null)
            {
                img.Dispose();
                img = null;
            }
        }

        // Irgendeine Assembly laden:
        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "";
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel) return;
            try
            {
                ass = Assembly.LoadFrom(openFileDialog1.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            loadResources();
        }

        //Eine Ressource in der ListBox ausw�hlen, 
        // falls darin eine Bilddatei enthalten ist, wird deren Inhalt angezeigt:
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex < 0) return;
            Stream stream = null;
            try
            {
                stream = ass.GetManifestResourceStream((string) listBox1.SelectedItem);
                Image img = Image.FromStream(stream);
                Image oldImage = pictureBox1.Image;
                pictureBox1.Image = img;
                if (oldImage != null)      // alte Bildressource freigeben
                {
                    oldImage.Dispose();
                    oldImage = null;
                }
            }
            catch { }
            finally
            {
                if (stream != null) stream.Close();
            }
        }

        //Ressource als separate Datei abspeichern:
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex < 0) return;
            saveFileDialog1.FileName = (string)listBox1.SelectedItem;
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel) return;
            Stream outFile = saveFileDialog1.OpenFile();
            Stream inFile = ass.GetManifestResourceStream((string)listBox1.SelectedItem);
            long len = inFile.Length;
            if (len > int.MaxValue)
            {
                MessageBox.Show("Kann Datei in dieser Version leider nicht abspeichern!");
                outFile.Close();
                inFile.Close();
            }
            byte[] bytes = new byte[len];
            inFile.Read(bytes, 0, (int)len);
            outFile.Write(bytes, 0, (int)len);
            inFile.Close();
            outFile.Close();
        }

        // Beenden:
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}