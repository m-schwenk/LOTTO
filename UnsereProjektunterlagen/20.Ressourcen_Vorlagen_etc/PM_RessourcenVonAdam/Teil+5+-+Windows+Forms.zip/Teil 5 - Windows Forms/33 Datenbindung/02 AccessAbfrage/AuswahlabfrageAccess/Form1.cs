using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AuswahlabfrageAccess
{
    using System.Data.OleDb;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=Nordwind.mdb;";
            OleDbConnection conn = new OleDbConnection(connStr);

            OleDbCommand cmd = new OleDbCommand("[Ums�tze nach Jahr]", conn); // in [ ] einschlie�en!!!
            cmd.CommandType = CommandType.StoredProcedure;
            OleDbParameter parm1 = new OleDbParameter("@Anfangsdatum", OleDbType.DBDate);  // !
            parm1.Direction = ParameterDirection.Input;
            parm1.Value = Convert.ToDateTime(textBox1.Text);
            cmd.Parameters.Add(parm1);
            OleDbParameter parm2 = new OleDbParameter("@EndDatum", OleDbType.DBDate);
            parm2.Direction = ParameterDirection.Input;
            parm2.Value = Convert.ToDateTime(textBox2.Text);
            cmd.Parameters.Add(parm2);        
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
           DataSet ds = new DataSet();
	       try
	       {
		      conn.Open();
		      da.Fill(ds, "Jahresums�tze");
		      conn.Close();
	       }
	       catch(Exception ex)
	       {
		       MessageBox.Show(ex.ToString());
	       }        
           // Die Anzeige:
           dataGridView1.DataSource = ds;
           dataGridView1.DataMember = "Jahresums�tze";
           // Formatierung der W�hrungsspalte:
           dataGridView1.Columns.Remove("Zwischensumme");
           DataGridViewTextBoxColumn tbc = new DataGridViewTextBoxColumn();
           tbc.DataPropertyName = "Zwischensumme";
           tbc.HeaderText = "Zwischensumme";
           tbc.Width = 80;
           tbc.DefaultCellStyle.Format = "c";
           tbc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
           tbc.DefaultCellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
           tbc.DisplayIndex = 2;
           dataGridView1.Columns.Add(tbc);
       }
    }
}
