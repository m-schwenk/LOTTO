using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Datenquellen_Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.customersTableAdapter.Update(this.northwindDataSet.Customers);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile l�dt Daten in die Tabelle "northwindDataSet.Customers". Sie k�nnen sie bei Bedarf verschieben oder entfernen.
            this.customersTableAdapter.Fill(this.northwindDataSet.Customers);

        }

        private void fillByCityToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.customersTableAdapter.FillByCity(this.northwindDataSet.Customers, cityToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void customersBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }
    }
}