using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataRelation_Demo
{
    using System.Data.OleDb;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connStr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=Nordwind.mdb;";
            OleDbConnection conn = new OleDbConnection(connStr);

            // Tabelle Kunden laden:
            string selStr = "SELECT KundenCode, Firma, Kontaktperson, Telefon FROM Kunden";
            OleDbDataAdapter da = new OleDbDataAdapter(selStr, conn);
            DataSet ds = new DataSet();
            conn.Open();
            da.Fill(ds, "Kunden");

            // Tabelle Bestellungen laden:
            selStr = "SELECT Bestellungen.BestellNr, Bestellungen.KundenCode," +
                   " Bestellungen.Bestelldatum, Bestellungen.Versanddatum" +
                   " FROM Kunden, Bestellungen WHERE (Kunden.KundenCode = Bestellungen.KundenCode)";
            da = new OleDbDataAdapter(selStr, conn);
            da.Fill(ds, "Bestellungen");
            conn.Close();
           // DataRelation zum DataSet hinzuf�gen:
	        ds.Relations.Add("KundenBestellungen", ds.Tables["Kunden"].Columns["KundenCode"],
          					ds.Tables["Bestellungen"].Columns["KundenCode"]);        
           // Anbinden des DataGrid:
	       dataGrid1.SetDataBinding(ds, "Kunden");        
        }

   }
    
}