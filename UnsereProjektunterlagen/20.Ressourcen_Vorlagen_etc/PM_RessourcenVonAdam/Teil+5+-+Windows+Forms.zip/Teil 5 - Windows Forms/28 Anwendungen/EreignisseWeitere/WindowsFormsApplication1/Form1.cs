﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((e.Button == MouseButtons.Right) & 
                new Rectangle(10, 10, 100, 100).Contains(e.X, e.Y)) MessageBox.Show("Erfolg");
        }

        private void listBox1_MouseEnter(object sender, EventArgs e)
        {
            (sender as ListBox).BackColor = Color.Blue;
        }
        
        private void listBox1_MouseLeave(object sender, EventArgs e)
        {
            (sender as ListBox).BackColor = Color.White;
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            //if ((e.KeyValue > 47) & (e.KeyValue < 58))
            //    listBox1.Items.Add((e.KeyValue-48).ToString());
            
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if ((e.KeyValue > 47) & (e.KeyValue < 58))
                listBox1.Items.Add((e.KeyValue - 48).ToString());
            e.Handled = true;
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (textBox2.Text.Length < 5)
            {
                MessageBox.Show("Bitte mehr als 5 Zeichen eingeben!");
                e.Cancel = true;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Programm beenden?", "Frage", MessageBoxButtons.YesNo) == DialogResult.No;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawEllipse(new Pen(Color.Black), 0, 0, 100, 100);
        }
    }
}
