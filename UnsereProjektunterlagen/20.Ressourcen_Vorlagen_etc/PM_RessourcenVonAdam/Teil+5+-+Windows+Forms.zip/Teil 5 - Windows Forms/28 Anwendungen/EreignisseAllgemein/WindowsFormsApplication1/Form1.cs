﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            // this.Text = (sender as TextBox).Text;
        }

        private void control_TextChanged(object sender, EventArgs e)
        {
            switch (sender.GetType().Name)
            {
                case "TextBox": this.Text = (sender as TextBox).Text; break;
                case "ComboBox": this.Text = (sender as ComboBox).Name; break;
            }            
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            int i = e.X;
        }       

        
    }
}
