﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Printing;

namespace DruckerKonfigurationKomplett
{
    public partial class Form1 : Form
    {

        private int page;

        private void aktualisieren()
        {
            comboBox1.Text = printDocument1.PrinterSettings.PrinterName;

            comboBox2.Items.Clear();
            foreach (PaperSize ps in printDocument1.PrinterSettings.PaperSizes)
                comboBox2.Items.Add(ps);
            comboBox2.Text = printDocument1.DefaultPageSettings.PaperSize.ToString();

            if (printDocument1.DefaultPageSettings.Landscape)
                comboBox3.SelectedIndex = 0;
            else
                comboBox3.SelectedIndex = 1;

            comboBox4.Items.Clear();
            foreach (PrinterResolution res in printDocument1.PrinterSettings.PrinterResolutions)
                comboBox4.Items.Add(res);
            comboBox4.Text = printDocument1.DefaultPageSettings.PrinterResolution.ToString();
        }

        
        public Form1()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
            aktualisieren();
        }

        private void Button3_Click(object sender, EventArgs e)
        {

            pageSetupDialog1.PageSettings.Margins.Left = (int)(pageSetupDialog1.PageSettings.Margins.Left * 2.54);
            pageSetupDialog1.PageSettings.Margins.Top = (int)(pageSetupDialog1.PageSettings.Margins.Top * 2.54);
            pageSetupDialog1.PageSettings.Margins.Right = (int)(pageSetupDialog1.PageSettings.Margins.Right * 2.54);
            pageSetupDialog1.PageSettings.Margins.Bottom = (int)(pageSetupDialog1.PageSettings.Margins.Bottom * 2.54);
            pageSetupDialog1.ShowDialog();
            aktualisieren();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
//### hier noch 2x 5 aktivieren
            printPreviewDialog1.WindowState = FormWindowState.Maximized;
            printPreviewDialog1.ShowDialog();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.printPreviewControl1.Document = printDocument1;
            f2.ShowDialog();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            printDocument1.Print();    
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printDocument1_EndPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            if (!printPreviewDialog1.Visible) MessageBox.Show(printDocument1.DocumentName + " wurde erfolgreich gedruckt!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (String s in PrinterSettings.InstalledPrinters)
                comboBox1.Items.Add(s);
            aktualisieren();
        }

        private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            page = 1;
            printDocument1.DocumentName = "Mein erstes Testdokument";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Pen p = new Pen(System.Drawing.Color.Black, 1);
            Random rnd = new Random();
            Graphics g = e.Graphics;
            int printpage = 0;


            // Umschalten in Millimeter
            g.PageUnit = GraphicsUnit.Millimeter;

            // Berücksichtigung des Druckbereichs
            switch (e.PageSettings.PrinterSettings.PrintRange)
            {
                case PrintRange.SomePages:
                    printpage = page + e.PageSettings.PrinterSettings.FromPage - 1;
                    break;
                case PrintRange.AllPages:
                    printpage = page;
                    break;
            }


            switch (printpage)
            {
                case 1:
                    g.FillRectangle(new SolidBrush(Color.Blue), 30, 30, 100, 100);
                    g.FillRectangle(new SolidBrush(Color.Green), 40, 40, 100, 100);
                    g.FillRectangle(new SolidBrush(Color.Yellow), 50, 50, 100, 100);
                    g.FillRectangle(new SolidBrush(Color.Cyan), 60, 60, 100, 100);
                    g.FillRectangle(new SolidBrush(Color.Red), 70, 70, 100, 100);
                    break;
                case 2:
                    g.DrawLine(new Pen(Color.Black, 10), 50, 100, 150, 200);
                    g.DrawLine(new Pen(Color.Black, 10), 50, 200, 150, 100);
                    break;
                case 3:
                    g.DrawString("Grafik 100%", new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Black, 70, 50);
                    g.DrawImage(pictureBox1.Image, 50, 100);
                    break;
                case 4:
                    g.DrawString("Grafik 10cm breit", new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Black, 70, 50);
                    g.DrawImage(pictureBox1.Image, 50, 100, 100, pictureBox1.Image.Height * 100 % pictureBox1.Image.Width);
                    g.DrawRectangle(new Pen(Color.Black, 0.1f), 50, 100, 100, pictureBox1.Image.Height * 100 % pictureBox1.Image.Width);
                    break;
                case 5:
                    g.DrawString("Seitenränder", new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Black, 70, 50);
                    g.PageUnit = GraphicsUnit.Display;
                    g.DrawRectangle(new Pen(Color.Black), e.MarginBounds);
                    g.PageUnit = GraphicsUnit.Millimeter;
                    break;
                case 6:
                    RectangleF rect = new RectangleF();
                    rect = (RectangleF) e.MarginBounds;
                    g.PageUnit = GraphicsUnit.Display;
                    g.DrawString(TextBox1.Text, new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Black, rect);
                    g.PageUnit = GraphicsUnit.Millimeter;
                    break;
                case 7:
                    RectangleF rect1 = new RectangleF();
                    StringFormat format = new StringFormat();
                    format.Alignment = StringAlignment.Center;
                    rect1 = (RectangleF) e.MarginBounds;
                    g.PageUnit = GraphicsUnit.Display;
                    g.DrawString(TextBox1.Text, new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Black, rect1, format);
                    g.PageUnit = GraphicsUnit.Millimeter;
                    break;
                case 8:
                    g.DrawString("Zufallslinien ohne Clipping", new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.White, 70, 50);
                    g.PageUnit = GraphicsUnit.Display;
                    for (int i = 0; i <= 500; i++)
                        g.DrawLine(p, 0, 0, rnd.Next(e.PageBounds.Width), rnd.Next(e.PageBounds.Height));
                    break;
                case 9:
                    g.DrawString("Zufallslinien mit Clipping", new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.White, 70, 50);
                    g.PageUnit = GraphicsUnit.Display;
                    g.SetClip(e.MarginBounds);
                    for (int i = 0; i <= 500; i++)
                        g.DrawLine(p, 0, 0, rnd.Next(e.PageBounds.Width), rnd.Next(e.PageBounds.Height));
                    break;
                case 10:
                    g.PageUnit = GraphicsUnit.Display;
                    g.SetClip(e.MarginBounds);
                    g.TranslateTransform(e.MarginBounds.Left, e.MarginBounds.Top);
                    for (int i = 0; i <= 500; i++)
                        g.DrawLine(p, 0, 0, rnd.Next(e.PageBounds.Width), rnd.Next(e.PageBounds.Height));
                    break;
            }

            // Seitennummer einblenden
            g.DrawString("Seite : " + printpage, new Font("Arial", 10, FontStyle.Bold, GraphicsUnit.Millimeter), Brushes.Red, 10, 10);
            // vorbereiten der nächsten Seite
            page++;
            // Berücksichtigung des Druckbereichs
            switch (e.PageSettings.PrinterSettings.PrintRange)
            {
                case PrintRange.SomePages:
                    e.HasMorePages = (printpage < e.PageSettings.PrinterSettings.ToPage);
                    break;
                case PrintRange.AllPages:
                    e.HasMorePages = (page < 11);
                    break;
            }
        }
    }
}