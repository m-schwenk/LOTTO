﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DruckerKonfigurationKomplett
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            printPreviewControl1.StartPage++;    
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (printPreviewControl1.StartPage > 0) printPreviewControl1.StartPage--;    
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            printPreviewControl1.AutoZoom = false;
            printPreviewControl1.Zoom = 200;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            printPreviewControl1.Columns = 2;
            printPreviewControl1.Rows = 2;
            printPreviewControl1.AutoZoom = true;
        }

 
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            printPreviewControl1.StartPage = 0;    
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            printPreviewControl1.StartPage = 999;    
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}