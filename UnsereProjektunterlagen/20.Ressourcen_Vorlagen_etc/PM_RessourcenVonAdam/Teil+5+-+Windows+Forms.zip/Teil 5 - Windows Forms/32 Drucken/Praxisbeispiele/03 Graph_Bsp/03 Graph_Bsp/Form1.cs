﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _03_Graph_Bsp
{
    public partial class Form1 : Form
    {
        private int page;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series[0].Name = "Umsätze TFT";
            chart1.Series[0].Points.AddXY(2007, 10);
            chart1.Series[0].Points.AddXY(2008, 25);
            chart1.Series[0].Points.AddXY(2009, 75);
            chart1.Series[0].Points.AddXY(2010, 150);
            chart1.ChartAreas.Add("Area2");
            chart1.Series.Add("Umsätze Telefone");
            chart1.Series[1].ChartArea = "Area2";
            chart1.Series[1].Points.AddXY(2007, 150);
            chart1.Series[1].Points.AddXY(2008, 65);
            chart1.Series[1].Points.AddXY(2009, 15);
            chart1.Series[1].Points.AddXY(2010, 5);
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            g.PageUnit = GraphicsUnit.Millimeter;
            switch (page)
            {
                case 1:
                    g.FillRectangle(new SolidBrush(Color.Blue), 30, 30, 100, 100);
                    break;
                case 2:
                    chart1.Printing.PrintPaint(g, new Rectangle(10, 10, 180, 250));  // !!!!!!!!!!
                    break;
            }
            page++;
            e.HasMorePages = page < 3;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            page = 1;
            printDocument1.DocumentName = "Mein erstes Testdokument";
        }
    }
}
