﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Word = Microsoft.Office.Interop.Word;

namespace Word1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var wordapp = new Word.Application();
            if (wordapp == null)
            {
                MessageBox.Show("Konnte keine Verbindung zu Word herstellen!");
                return;
            }
            wordapp.Visible = true;
            wordapp.Documents.Add();
            if (wordapp.ActiveWindow.View.SplitSpecial != 0) wordapp.ActiveWindow.Panes[2].Close();
            if (((int)wordapp.ActiveWindow.ActivePane.View.Type == 1) | ((int)wordapp.ActiveWindow.ActivePane.View.Type == 2) | ((int)wordapp.ActiveWindow.ActivePane.View.Type == 5)) wordapp.ActiveWindow.ActivePane.View.Type = Word.WdViewType.wdPrintView;
            wordapp.ActiveWindow.ActivePane.View.SeekView =  Word.WdSeekView.wdSeekCurrentPageHeader;
            wordapp.Selection.Font.Name = "Times New Roman";
            wordapp.Selection.Font.Size = 12;
            wordapp.Selection.Font.Bold = 1;

            wordapp.Selection.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            wordapp.Selection.TypeText("Kohlenhandel Brikett-GmbH & Co.-KG. - Holzweg 16 - 54633 Steinhausen");
            wordapp.ActiveWindow.ActivePane.View.SeekView = Word.WdSeekView.wdSeekCurrentPageFooter;
            wordapp.Selection.TypeText("Bankverbindung: Stadtsparkasse Steinhausen BLZ 123456789   KtoNr. 782972393243");
            wordapp.ActiveWindow.ActivePane.View.SeekView = Word.WdSeekView.wdSeekMainDocument;
            wordapp.Selection.TypeText(textBox2.Text + " " + textBox1.Text);
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeText(textBox3.Text);
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.Font.Name = "Times New Roman";
            wordapp.Selection.Font.Size = 12;
            wordapp.Selection.Font.Bold = 1;
            wordapp.Selection.TypeText(textBox4.Text + " " + textBox5.Text);
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();

            wordapp.Selection.Font.Name = "Arial";
            wordapp.Selection.Font.Size = 14;
            wordapp.Selection.Font.Bold = 1;
            wordapp.Selection.TypeText(comboBox1.Text);
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();
            wordapp.Selection.TypeParagraph();

            wordapp.Selection.Font.Name = "Times New Roman";
            wordapp.Selection.Font.Size = 12;
            wordapp.Selection.Font.Bold = 1;

            if (comboBox2.SelectedIndex == 0)
                wordapp.Selection.TypeText("Sehr geehrter Herr " + textBox1.Text);
            else
                wordapp.Selection.TypeText("Sehr geehrte Frau " + textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = 0;
        }
    }
}